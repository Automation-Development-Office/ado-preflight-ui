<!--# cspell: ignore SSOT CMDB -->

# AGENTS.md — infra.ado

Ansible collection source for ADO bootstrap (`infra.ado`).

## Always-on reminder

Full copy: [docs/ADO-LAB-RESET.md](docs/ADO-LAB-RESET.md)

```text
ADO lab: say "ADO-LAB Reset" to reload context. Read each open repo's AGENTS.md.
Lab rules: /home/chelliot/openshift/git/github-ado/.cursor/rules/local/
Do not ask for passwords — use lab-creds + ~/Downloads/ado-preflight-*.json.
Fix code not Controller. User runs restart_pod.sh / preflight / sync / relaunch.
```

## Ansible coding standards

Follow [ansible-creator agents.md](https://raw.githubusercontent.com/ansible/ansible-creator/refs/heads/main/docs/agents.md)
(Zen of Ansible, role structure, naming, lint/test expectations).

Also see [docs/ADO_DEVELOPMENT_MODEL.md](docs/ADO_DEVELOPMENT_MODEL.md).

## Lab context reload

When the user says **`ADO-LAB Reset`** (any casing), treat it as a full context reload.
Do not ask them to paste the checklist — the phrase **is** the checklist.

Lab rules (gitignored) live on the **parent** tree, not inside this collection:

`../.cursor/rules/local/` → `agent-reset.mdc`, `chad-lab-ado.mdc`, `lab-creds.mdc`

1. Re-read those three files under `github-ado/.cursor/rules/local/`
2. Re-read `ado-preflight-ui/.cursor/rules/local/chad-lab-preflight.mdc`
3. Skim `ado-cluster-portal` and `lab-tools-dont-delete` local rules if the task touches portal / VPN / IdM
4. Load newest matching `~/Downloads/ado-preflight-*.json` (picker in `lab-creds.mdc`)
5. Confirm `galaxy.yml` version matches newest `ado-preflight-ui/collections/infra-ado-*.tar.gz`
6. Prefer Chad AAP unless preflight JSON says otherwise
7. **Fix code, not Controller** — user runs `restart_pod.sh` + preflight + project sync + JT relaunch

Do not commit tokens, vault plaintext, or preflight JSON exports.

## Cross-repo map

```text
ado/                    → this repo — infra.ado collection source
ado-preflight-ui/       → form + server.js + baked collection tarball
bootstrap-sample/       → generated group_vars + playbooks (Controller SCM)
ado-cluster-portal/     → lab link hub + VPN self-service (portal.rhlabchad.com)
lab-tools-dont-delete/  → IdM / VPN / Satellite / Virt JTs (not in this collection)
```

Canonical sibling paths live under `…/github-ado/` (not stale `…/git/ado-preflight-ui`).

## Hard rules (this repo)

| Do | Do not |
|----|--------|
| Put bootstrap logic in roles / env gen / JT seeds | Ship permanent behavior only in preflight `server.js` |
| Wire new JTs into workflows (`files/` + `templates/`) | Leave a JT orphaned from the component workflow |
| Same-version tarball rebuild after fixes | Bump `galaxy.yml` version unless user asks |
| Use existing `infra.ado` roles for lab platforms | Freelance raw ssh/curl installs when a role/JT exists |
| Diagnose AAP/OCP with read-only APIs | Patch live AAP/OCP as the delivery path (unless user says so) |
| Changelog fragment + role README for user-visible changes | Skip lint/README gates on material role changes |

## Deploy loop after a collection fix

Agent may build and copy the tarball:

```bash
ansible-galaxy collection build -o /tmp
cp /tmp/infra-ado-*.tar.gz ../ado-preflight-ui/collections/
```

**User** then: `ado-preflight-ui/./restart_pod.sh` → re-run preflight bootstrap → git push bootstrap repo → Controller project sync → relaunch failed JTs.

## CLI ≡ UI

Preflight UI is a form + runner. Bootstrap semantics live in this collection.
Same preflight JSON + `run-ado-scaffolding.yml` must work from CLI without UI-only logic.
