# ADO-LAB Reset

Say this in chat when context is stale (any casing):

**`ADO-LAB Reset`**

## Always-on agent reminder

```text
ADO lab: say "ADO-LAB Reset" to reload context. Read each open repo's AGENTS.md.
Lab rules: /home/chelliot/openshift/git/github-ado/.cursor/rules/local/
Do not ask for passwords — use lab-creds + ~/Downloads/ado-preflight-*.json.
Fix code not Controller. User runs restart_pod.sh / preflight / sync / relaunch.
```

## What the phrase does

1. Re-read `/home/chelliot/openshift/git/github-ado/.cursor/rules/local/`
   (`agent-reset.mdc`, `chad-lab-ado.mdc`, `lab-creds.mdc`)
2. Re-read sibling local rules (`ado-preflight-ui`, portal, lab-tools) as needed
3. Load newest matching `~/Downloads/ado-preflight-*.json`
4. Confirm collection tarball vs `galaxy.yml`
5. Fix code in `infra.ado` / preflight — not live Controller/OCP (unless you ask)

See also: [AGENTS.md](../AGENTS.md), [ADO_DEVELOPMENT_MODEL.md](ADO_DEVELOPMENT_MODEL.md).
