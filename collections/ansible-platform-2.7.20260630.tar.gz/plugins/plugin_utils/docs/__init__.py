"""Module documentation strings (DOCUMENTATION)."""
