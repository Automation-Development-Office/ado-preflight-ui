# Grafana dashboard templates

Copied into generated playbook repos by `infra.ado.bootstrap_generate_playbook_repo`.

Layout matches Grafana multi-folder upload (`grafana_folders`):

| Grafana folder | Path |
|----------------|------|
| Openshift | `templates/Openshift/dashboards/*.json.j2` |
| RHACS | `templates/RHACS/dashboards/*.json` |

### Cluster resource overview (Prod / Dev)

Two dashboards mirror a classic K8s node/pod/network overview:

| File | UID | Title |
|------|-----|-------|
| `openshift-prod-cluster-resource-overview.json.j2` | `ado-ocp-prod-resource-overview` | OpenShift Prod — Cluster Resource Overview |
| `openshift-dev-cluster-resource-overview.json.j2` | `ado-ocp-dev-resource-overview` | OpenShift Dev — Cluster Resource Overview |

### K8S dashboard (Prod / Dev)

Adapted from [Grafana 15661](https://grafana.com/grafana/dashboards/15661-k8s-dashboard-en-20250125/)
(K8S for Prometheus EN):

| File | UID | Title |
|------|-----|-------|
| `openshift-prod-k8s-dashboard.json.j2` | `ado-ocp-prod-k8s-dashboard` | OpenShift Prod — K8S Dashboard |
| `openshift-dev-k8s-dashboard.json.j2` | `ado-ocp-dev-k8s-dashboard` | OpenShift Dev — K8S Dashboard |

### Keycloak metrics (Prod / Dev)

Adapted from [Grafana 10441](https://grafana.com/grafana/dashboards/10441-keycloak-metrics-dashboard/)
(Keycloak Metrics SPI). Requires Keycloak metrics in Prometheus
([keycloak-metrics-spi](https://github.com/aerogear/keycloak-metrics-spi) or equivalent).

| File | UID | Title |
|------|-----|-------|
| `keycloak-metrics-prod.json.j2` | `ado-keycloak-metrics-prod` | OpenShift Prod — Keycloak Metrics |
| `keycloak-metrics-dev.json.j2` | `ado-keycloak-metrics-dev` | OpenShift Dev — Keycloak Metrics |

### cert-manager expiry (Prod / Dev)

Inspired by community cert-manager views (e.g. [11001](https://grafana.com/grafana/dashboards/11001)).
Shows **time left until expiry** for all cert-manager `Certificate` CRs, plus a
**Main ADO** table filtered for Keycloak, Grafana, AAP/controller, Portal, Quay,
GitLab, ACS/Central, and related names. TLS secrets **without** a `Certificate`
CR do not appear in Prometheus — use `oc get certificate -A` to confirm coverage.

| File | UID | Title |
|------|-----|-------|
| `cert-manager-expiry-prod.json.j2` | `ado-cert-manager-expiry-prod` | OpenShift Prod — cert-manager Expiry |
| `cert-manager-expiry-dev.json.j2` | `ado-cert-manager-expiry-dev` | OpenShift Dev — cert-manager Expiry |

Use the **K8S** datasource variable at the top to point each dashboard at the
matching Prometheus. ADO `grafana_create_datasource` creates:

| Datasource name | Default source |
|-----------------|----------------|
| `Openshift-Prod` | Local `thanos-querier` (platform + user-workload metrics) |
| `Openshift-Dev` | Remote Dev Prometheus URL + token (`grafana-openshift-dev-prometheus` Secret / vault) |

Prod dashboards filter names matching `prod` / `openshift-prod` / `Openshift`;
Dev dashboards match `dev` / `openshift-dev`.

**cert-manager dashboards** also need a `ServiceMonitor` in `cert-manager` with
`honorLabels: true` (ADO `ocp_cert_manager` creates this) so Certificate
`namespace`/`name` labels are preserved.

Run **ADO | Deploy Grafana** (full) or **ADO | Deploy Grafana dashboards**
(datasources + folders + import) so secrets, datasources, folders, and dashboards
are created by the collection — do not one-off API import.

- `.json.j2` files are rendered as Jinja before upload.
- Plain `.json` files are uploaded as-is.

Example `grafana_folders` entries (paths relative to the playbook repo root):

```yaml
grafana_folders:
  - name: Openshift
    source_type: path
    source: templates/Openshift
    dashboards_path: dashboards
    alerts_path: alerts
  - name: RHACS
    source_type: path
    source: templates/RHACS
    dashboards_path: dashboards
```

The RHACS vulnerability dashboard (`rhacs-vulnerability-overview.json`, UID
`ado-rhacs-vuln-posture`) is a sample built from scrubbed prod report data and
uses the Grafana TestData datasource. Replace the datasource / panel queries
with live report metrics when wiring production feeds.
