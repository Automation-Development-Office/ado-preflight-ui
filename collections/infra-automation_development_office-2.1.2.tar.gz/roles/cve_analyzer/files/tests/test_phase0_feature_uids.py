"""Phase 0 feature UID allowlist — portable Stage/Preprod UIDs."""

from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

FILES = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(FILES))

import build_rhacs_vuln_dashboard as builder  # noqa: E402

PROD = "ado-rhacs-vuln-posture"
PHASE0 = "ado-rhacs-vuln-posture-phase0"
CUSTOM = "ado-rhacs-vuln-posture-new"
LITE = "ado-lite"


class Phase0FeatureUidsTest(unittest.TestCase):
    def tearDown(self):
        os.environ.pop("CVE_ANALYZER_PHASE0_FEATURE_UIDS", None)
        os.environ.pop("CVE_ANALYZER_PHASE0_HYBRID_UIDS", None)
        os.environ.pop("CVE_ANALYZER_CVE_INTEL_PANELS", None)

    def test_production_never_feature_uid(self):
        os.environ["CVE_ANALYZER_PHASE0_FEATURE_UIDS"] = CUSTOM
        self.assertTrue(builder.is_production_posture_uid(PROD))
        self.assertFalse(builder.is_phase0_feature_uid(PROD))
        # Filterable+legacy trends are on for production; hybrid All→legacy is not.
        self.assertTrue(builder.phase1_filterable_trend(PROD))
        self.assertFalse(builder.phase1_hybrid_trend(PROD))

    def test_builtin_phase0_and_lite(self):
        self.assertTrue(builder.is_phase0_feature_uid(PHASE0))
        self.assertTrue(builder.is_phase0_feature_uid(LITE))
        self.assertTrue(builder.phase1_filterable_trend(PHASE0))
        self.assertTrue(builder.phase1_hybrid_trend(PHASE0))

    def test_custom_uid_requires_allowlist(self):
        self.assertFalse(builder.is_phase0_feature_uid(CUSTOM))
        self.assertFalse(builder.phase1_filterable_trend(CUSTOM))
        os.environ["CVE_ANALYZER_PHASE0_FEATURE_UIDS"] = CUSTOM
        self.assertTrue(builder.is_phase0_feature_uid(CUSTOM))
        self.assertTrue(builder.phase1_filterable_trend(CUSTOM))
        self.assertTrue(builder.phase1_hybrid_trend(CUSTOM))

    def test_cve_intel_panels_custom_uid_with_flag(self):
        os.environ.pop("CVE_ANALYZER_CVE_INTEL_PANELS", None)
        os.environ["CVE_ANALYZER_PHASE0_FEATURE_UIDS"] = CUSTOM
        self.assertFalse(
            builder._cve_intel_panels_enabled(CUSTOM, cve_intel_panels=False)
        )
        self.assertTrue(
            builder._cve_intel_panels_enabled(CUSTOM, cve_intel_panels=True)
        )

    def test_cve_intel_panels_never_on_production_even_with_flag(self):
        os.environ["CVE_ANALYZER_PHASE0_FEATURE_UIDS"] = CUSTOM
        self.assertFalse(
            builder._cve_intel_panels_enabled(PROD, cve_intel_panels=True)
        )

    def test_cve_intel_panels_phase0_unchanged(self):
        os.environ.pop("CVE_ANALYZER_CVE_INTEL_PANELS", None)
        self.assertFalse(
            builder._cve_intel_panels_enabled(PHASE0, cve_intel_panels=False)
        )
        self.assertTrue(
            builder._cve_intel_panels_enabled(PHASE0, cve_intel_panels=True)
        )

    def test_env_flag_enables_on_allowlisted_uid(self):
        os.environ["CVE_ANALYZER_PHASE0_FEATURE_UIDS"] = CUSTOM
        os.environ["CVE_ANALYZER_CVE_INTEL_PANELS"] = "true"
        self.assertTrue(
            builder._cve_intel_panels_enabled(CUSTOM, cve_intel_panels=False)
        )


if __name__ == "__main__":
    unittest.main()
