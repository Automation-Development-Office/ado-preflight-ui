==================================
Infra Ado Collection Release Notes
==================================

.. contents:: Topics

v2.0.0
======

Minor Changes
-------------

- ado-preflight-ui - Admin HTPasswd form includes Login button name (IdP) wired through bootstrap vars and Contoller JT survey.
- ado-preflight-ui - Move Credentials and Git under AAP Configuration tabs; RHBK OpenShift form adds TLS mode (edge / cert-manager / own cert upload).
- bootstrap_controller - Add ``ADO | Satellite Capsule Install`` job template wired to ``infra.ado.capsule_install``.
- bootstrap_controller - Include selected Pega playbooks and job templates in generated bootstrap output.
- bootstrap_controller - Nest cert-manager under ``ADO | Cert Manager Workflow`` (deploy, optional IdM ACME / AWS PCA, optional default ingress), referenced from ``ADO | OpenShift Workflow`` like RHBK and Grafana.
- bootstrap_generate_env_vars - Map Pega disconnected inputs and remove obsolete lab-specific generated defaults.
- bootstrap_generate_env_vars - Map delivery and policy inputs.
- bootstrap_generate_env_vars - Write ``capsule_install_*`` variables into ``vars_satellite.yml`` / ``vault_satellite.yml`` and seed a dedicated Capsule AAP inventory.
- bootstrap_generate_playbook_repo - Generate GitOps and policy files.
- bootstrap_generate_playbook_repo - Generate ``playbooks/satellite/ado-install-capsule-bootstrap.yml`` for the ``satellite_capsule_install`` app.
- bootstrap_generate_playbook_repo - Generate a local component execution plan and CLI runner from selected playbooks and existing workflow ordering. Validate selections and required survey inputs, preview commands, and stop execution on the first failed playbook without requiring Controller.
- bootstrap_generate_playbook_repo - Local no-AAP component runner accepts per-playbook ``step_options`` (typed ``vars``, optional ``state``, and freeform ``extra_args``) so Preview/Run can override Common extra vars for a single step.
- bootstrap_generate_playbook_repo - Local no-AAP component runner no longer re-prompts Contoller survey fields; generated ``group_vars`` from the form are the source of truth.
- bootstrap_generate_playbook_repo - Replace the Pega failure placeholder with the ocp_pega role.
- bootstrap_resolve_component - Prefer RHBK operator channel ``stable-v26.2`` so login-event metrics are available after upgrade.
- capsule_install - Added HAProxy template and integration_capsule_install Molecule scenario.
- capsule_install - Added firewall, DNS, and custom Capsule certificate generation tasks after package installation.
- capsule_install - Added package installation after storage configuration when ``satellite-capsule`` is not already installed.
- capsule_install - Ensure ``firewalld`` is installed before enabling the ``RH-Satellite-6-capsule`` service and opening load-balancer ports.
- capsule_install - Install packages from ``capsule_install_packages`` instead of ``satellite_install_packages``.
- capsule_install - Renamed OAuth consumer facts to ``capsule_install_foreman_proxy_oauth_consumer_key`` and ``capsule_install_foreman_proxy_oauth_consumer_secret``.
- capsule_install - Renamed numbered task files to install_capsule, post_config, sync_capsule, and haproxy; wired full install flow in main.yml.
- capsule_install - Skip load-balancer firewall delegation when ``capsule_install_loadbalancer_fqdn`` is unset so non-HAProxy runs do not fail firewall configuration.
- cert_manager - Preflight issuer selection uses clearable options (IdM ACME, AWS PCA, Custom); unchecking all keeps operator-only deploy (``mode=cert``). Contoller workflow follows cert-manager plus optional issuer and/or Default Ingress Cert.
- ci - Add the Red Hat partner certification checker workflow and Dependabot updates for GitHub Actions.
- galaxy.yml - Add the ``infrastructure`` tag required by Automation Hub import checks.
- grafana - Added standalone content playbooks under ``playbooks/grafana/`` (datasources, folders, dashboards, alerts, combined) for manual Contoller JT wiring without bootstrap install.
- grafana - Keycloak metrics dashboard adds login success/fail panels and failed-login table/rate by Keycloak ``error`` (bad password / unknown user).
- grafana_install - Add optional PostgreSQL backend for new OpenShift Grafana installs (``grafana_database_type: sqlite|postgres``). When postgres and ``grafana_database_provision=true`` (default), create Secret/PVC/Deployment/Service ``grafana-postgres`` and configure the Grafana CR ``database`` section. External Postgres is supported with ``grafana_database_provision=false`` plus host/user/ password. SQLite remains the default; SQLite→Postgres data migration is not automatic (separate follow-up workflow).
- grafana_install - Gate operator/CR install on ``grafana_install_scope=install`` so OIDC/email configure JTs no longer re-apply the full install path.
- grafana_upload_dashboards - Allow ``recurse: false`` on folder sources.
- install_rhbk - Add ``event_metrics_user_enabled`` / ``install_rhbk_event_metrics_user_enabled`` (default false until RHBK 26.2+) plus ServiceMonitor for management ``/metrics``.
- ocp_absent_cleanup - New role: safe OpenShift absent cleanup gate for Terminating namespaces, stuck finalizers, leftover CSVs/InstallPlans, and Deployments/pods (explicit namespace allowlist; refuses kube-* / platform NS).
- ocp_acm - Optional Multicluster Observability (``ocp_acm_observability_enabled``) creates the observability namespace, ``thanos-object-storage`` secret, and ``MultiClusterObservability`` CR so Fleet Virtualization Overview can show metrics. Requires S3-compatible object storage (MinIO supported). Preflight ACM tab checkbox + S3 fields.
- ocp_acm_policy - Generate namespace-label policies with explicit placement.
- ocp_devspaces - Default ``ocp_devspaces_status_exporter_enabled`` / preflight ``status_exporter_enabled`` to ``true`` so Grafana Dev Spaces dashboards get phase and VS Code extension metrics out of the box.
- ocp_devspaces - Optional DevWorkspace status metrics exporter (``status_exporter_enabled``) for Grafana; portable ``dw_*`` labels in the Dev Spaces operator namespace.
- ocp_devspaces - Share CheCluster rendering for direct and GitOps generation.
- ocp_devspaces - Status exporter can scrape VS Code extensions from Running workspace pods (``devworkspace_vscode_extension`` metric; needs pods/exec RBAC).
- ocp_devspaces / preflight - Add custom getting-started sample fields (display name, git/devfile URL, bundled ADO icon or upload) so Dev Spaces can replace stock samples with an ADO-branded card.
- ocp_gitops_application - Generate Applications and resource bundles.
- ocp_htpasswd_admin / bootstrap_generate_env_vars - Preflight ``openshift.htpasswd_idp_name`` sets the OpenShift console login button (OAuth IdP name); secret defaults to ``<idp>-secret``.
- ocp_image_registry - Add optional OpenShift integrated image registry enablement with merge-only Config patch, operational PASS/FAIL reporting, Contoller JT/workflow wiring, bootstrap prep, and preflight option ``integrated_image_registry``.
- ocp_mtv - New role plus bootstrap playbook / Contoller JT / OpenShift workflow node for Migration Toolkit for Virtualization (``mtv-operator`` + ``ForkliftController``). Preflight OpenShift app ``mtv``.
- ocp_namespace - ``state=absent`` now runs ``ocp_absent_cleanup`` before and after delete so every OpenShift namespace uninstall gets the same stuck-cleanup behavior.
- ocp_nfs_storage - Bundle ``csi-driver-nfs`` Helm chart ``files/charts/csi-driver-nfs-4.11.0.tgz`` (~12 KiB) and install from that path by default so bootstrap / Contoller runs do not need GitHub ``helm repo add``. Set ``ocp_nfs_storage_use_bundled_chart=false`` to use the upstream charts URL, or ``ocp_nfs_storage_chart_path`` for a custom archive. Container images referenced by the chart are unchanged.
- ocp_operator_subscription - ``state=absent`` runs ``ocp_absent_cleanup`` with CSV name match (workloads off by default for shared namespaces).
- ocp_pega - Add local-chart Helm deployment with offline image validation and optional OpenSearch and Backing Services.
- ocp_virtualization_install - Honor ``ocp_virtualization_install_enable_kube_secondary_dns`` by setting HyperConverged ``featureGates.deployKubeSecondaryDNS`` when creating the CR.
- preflight - RHBK checkbox for user-event metrics (enable after upgrading off ``stable-v26.0``).

Bugfixes
--------

- acm playbook - Stop passing a self-referential ``operatorgroup: "{{ operatorgroup | default(...) }}"`` into ``ocp_operatorgroups``. That recursion aborts absent after hub cleanup already succeeded; use the value from ``bootstrap_resolve_component``.
- acm playbook - Uninstall MultiClusterHub/subscription before OperatorGroup and namespace so hub controllers cannot recreate the OG mid-absent run.
- ado-preflight-ui - Typing Additional ansible-playbook options no longer swaps the playbook preview pane back to the bootstrap scaffolding command; click Preview commands to refresh.
- bookstack_openshift - OIDC-only scope reads existing bookstack-app Secret for APP_KEY before redeploy (fixes undefined bookstack_openshift_app_key_effective).
- bookstack_openshift - Remove invalid ``validate_certs`` from ``kubernetes.core.k8s*`` OIDC tasks (conflicting action statements).
- bootstrap_controller - Add missing ``Alt Routes Workflow`` nested node so OpenShift workflow success edges to alternate routes resolve when that sub-workflow is generated.
- bootstrap_controller - Hub Pulp URI auth no longer sets ``headers`` to ``omit`` under basic-auth (empty OAuth/Hub token), which left ``bootstrap_controller_hub_uri_headers`` undefined and crashed collection publish on hub-only / standalone runs.
- bootstrap_controller - Hub publish finds prebuilt ``infra-ado-*.tar.gz`` under ``/opt/ado-collections`` as well as ``/workspace``, so force updates stage the exact preflight tarball instead of silently rebuilding from ``ado-source``.
- bootstrap_controller - Hub-only collection/EE publish no longer skipped after a prior license-attach left ``aap_ocp_install_license_only`` / ``aap_install_during_bootstrap`` in group_vars. Resolve install flags from preflight only; only a full AAP operator install blocks Contoller apply (license-only attach does not).
- bootstrap_controller - Keep Configure LDAP in OpenShift on the OpenShift workflow when ldap_auth is selected (JT alone is not enough).
- bootstrap_controller - Lengthen Hub pulp import/promote waits (default ~10m; ~20m for tarballs >= 30MB such as ``redhat.rhel_system_roles``) so large collection publishes finish before Hub EE push.
- bootstrap_controller - Move ``environment`` off ``include_role`` onto a surrounding ``block`` in ``install_nfs_csi.yml``, ``install_iscsi_csi.yml``, and ``install_htpasswd.yml`` so ansible-core that rejects ``environment`` on IncludeRole no longer fails bootstrap CSI/HTPasswd prep.
- bootstrap_controller - Pass ``KUBECONFIG`` / ``K8S_AUTH_KUBECONFIG`` into ``ocp_image_registry`` during bootstrap prep, matching HTPasswd and CSI install tasks.
- bootstrap_controller - Resolve NFS/iSCSI CSI inputs with ``set_fact`` before ``include_role`` instead of ``ocp_* | default(alias)`` on the same var name, which recursed under ansible-core and failed the NFS CSI assert during bootstrap.
- bootstrap_controller - Retry Hub EE ``skopeo copy`` on registry 502/gateway flakes (skopeo ``--retry-times``/``--retry-delay`` plus Ansible retries).
- bootstrap_controller - Skip IdM ACME and AWSPCA job templates unless ``bootstrap_controller_cert_manager_mode`` is ``idm_acme`` or ``aws_pca``.
- bootstrap_controller - Treat OpenShift option ``nfs_csi`` / ``iscsi_csi`` as enabling install during bootstrap by default (``install_*_during_bootstrap`` defaults to true when the option is selected), so selecting the option in preflight actually runs the CSI install tasks.
- bootstrap_controller - Treat cert-manager ``mode=custom`` like ``cert`` when pruning OpenShift workflow nodes so IdM ACME and AWS PCA job templates are omitted unless those modes are selected.
- bootstrap_controller - Wait for an existing project update and reuse it when its source matches, instead of queuing a duplicate sync. Preserve failures rather than accepting stale successful revisions, and display actual project-update output in failure guidance.
- bootstrap_controller - Wire ``ADO | Deploy OpenShift Virtualization`` into the OpenShift workflow so selecting ``ocp_virtualization`` keeps a parallel root node (it was pruned because the JT existed but was never in ``simplified_workflow_nodes``).
- bootstrap_generate_env_vars - Admin HTPasswd rejects empty passwords instead of writing blank hashes (no silent ``redhat123`` default).
- bootstrap_generate_env_vars - Admin HTPasswd vault templates no longer hardcode ``redhat123``. Write real ``htpasswd_users`` into ``vault_htpass_admin.yml``, ``vault_admin_htpasswd.yml``, and ``vault_openshift.yml`` from preflight; drop the bogus ``admin_htpasswd: redhat123`` stub key.
- bootstrap_generate_env_vars - Always derive RHACS Central hostname as ``central.<apps_domain>`` when apps domain is set; ignore stale preflight form overrides for ``component_config.acs.hostname``.
- bootstrap_generate_env_vars - Clear stale ``license_only`` / ``install_during_bootstrap`` when preflight has attach/install off.
- bootstrap_generate_env_vars - Console Banner delete clears leftover banner text/color keys from prior adds in ``vars_openshift.yml``.
- bootstrap_generate_env_vars - Do not drop an explicit preflight StorageClass on ocp-dev (including synology-nfs-csi). Emptying storage left ACS/Quay/MinIO with no storage in group_vars.
- bootstrap_generate_env_vars - Exclude disabled Galaxy credentials from generated organization attachments so disabling public Galaxy is respected by bootstrap.
- bootstrap_generate_env_vars - For OpenShift RHBK, Grafana, and GitLab (standalone option not selected), do not write any ``standalone_*`` fields or RHEL ``install_*`` / zip / RPM / edition vars into group_vars — only when Standalone is selected.
- bootstrap_generate_env_vars - Hub hostname auto-discovers from Contoller ``aap.hostname`` unless ``hub_hostname_manual`` is true, so stale imported ``hub_hostname`` values no longer publish collections to the wrong Hub.
- bootstrap_generate_env_vars - Ignore stale ``component_apps.openshift`` entries that are not in the preflight UI checkbox catalog so leftover imports no longer generate unrelated playbooks.
- bootstrap_generate_env_vars - Ignore stale top-level ``components[]`` leftovers for non-UI OpenShift playbook apps (for example ``gitlab_runner``) so console-banner-only bootstrap no longer generates Deploy GitLab Runner in the local no-AAP run plan.
- bootstrap_generate_env_vars - Ignore stale top-level ``components[]`` leftovers for non-UI OpenShift playbook apps (for example ``gitlab_runner``) so option-only selections do not generate those playbooks.
- bootstrap_generate_env_vars - OpenShift Admin HTPasswd playbooks are generated only when ``component_options.openshift`` includes ``admin_htpasswd`` (not merely because admin username/password fields are present).
- bootstrap_generate_env_vars - Pass Quay OIDC client/realm and optional client secret from preflight ``component_config.quay``.
- bootstrap_generate_env_vars - Pin ``operator_channel: stable`` (and related subscription vars) into ``vars_ocp_virtualization.yml``; reject ACM-style ``release-*`` channels for CNV/HCO.
- bootstrap_generate_env_vars - RHBK OpenShift TLS supports ``manual`` mode (``tls.crt`` / ``tls.key`` into vault) alongside edge and cert-manager; stop silently defaulting Keycloak admin password to ``redhat123`` when unset.
- bootstrap_generate_env_vars - Select the console banner playbook only when ``console_banner`` is in OpenShift options (not merely because ``openshift.banner_text`` is present in imported preflight JSON).
- bootstrap_generate_env_vars - Stop forcing ``install_rhbk_platform: rhel`` when preflight UI ships default ``standalone_hostname`` / zip fields without the ``standalone`` RHBK option selected. OpenShift Deploy RHBK stays on the operator path; standalone ZIP vars apply only when ``standalone`` is checked.
- bootstrap_generate_env_vars - Stop wiping synology-nfs-csi storage on ocp-dev when that is also the cluster default (Quay/ACS/MinIO lost storage and ACS tried to patch PVCs to empty storageClassName).
- bootstrap_generate_env_vars - Wire OpenShift console banner ``state`` (add/update/delete), LDAP Auth ``ldap_config`` IdM fields, and OAuth/RHBK client/realm/scopes from preflight ``openshift.*`` into generated vars/vault.
- bootstrap_generate_env_vars - Write Admin HTPasswd ``htpasswd_users`` / ``htpasswd_pass`` into both ``vault_htpass_admin.yml`` (Contoller JT component) and ``vault_admin_htpasswd.yml`` (env-gen stub name). Fail hard when Admin HTPasswd is selected with an empty password — no silent default.
- bootstrap_generate_playbook_repo - Cert-manager Deploy creates ClusterIssuer ``idm-acme`` when ``ocp_cert_manager_mode`` / ``mode`` is ``idm_acme`` (preflight IdM ACME tab). Selecting that mode and running Deploy alone previously installed only the operator; the issuer stayed on a separate playbook/JT. Contoller Deploy JT uses the same playbook; the OpenShift workflow still runs ``ADO | Configure IDM ACME ClusterIssuer`` after Deploy when mode is ``idm_acme``.
- bootstrap_generate_playbook_repo - Cert-manager Deploy honors ``state=absent``: removes ADO ClusterIssuers (``idm-acme``, ``root-ca-issuer``, and optional extras), unsubscribes CSVs, deletes OperatorGroup and namespaces, and skips wait/configure steps that previously re-verified a still-running operator. Other ClusterIssuers on the cluster are left in place.
- bootstrap_generate_playbook_repo - Cert-manager ``state=absent`` now assert-gates operand/operator namespaces to the allowlist, then sweeps leftover CSVs/InstallPlans/Deployments/pods, re-deletes webhooks, clears cert-manager APIServices, and fails if namespaces remain. Prior runs deleted Subscriptions but left Failed CSVs that recreated Deployments and stuck ``cert-manager`` namespaces Terminating for hours.
- bootstrap_generate_playbook_repo - Cert-manager ``state=absent`` now uninstalls in a fixed order: ClusterIssuers and namespaced CRs (strip finalizers), admission webhooks, OLM Subscription/CSV, OperatorGroup, then namespaces with quick force-finalize. Prior deletes left webhooks and Terminating namespaces that broke every reinstall.
- bootstrap_generate_playbook_repo - Cert-manager absent CR flatten no longer uses ``json_query`` (requires jmespath). Loop-append resources so uninstall works in the preflight pod EE.
- bootstrap_generate_playbook_repo - Cert-manager absent removes ``cert-manager-webhook`` Validating/MutatingWebhookConfigurations before deleting namespaces so uninstall does not leave orphans that block the next install.
- bootstrap_generate_playbook_repo - Cert-manager absent uses ``ocp_absent_cleanup`` for namespace sweeps instead of one-off tasks.
- bootstrap_generate_playbook_repo - Create Admin HTPasswd playbook loads dedicated htpasswd vaults last so Contoller uses the preflight password.
- bootstrap_generate_playbook_repo - Default Ingress Cert no longer generates IdM ACME and AWSPCA local playbooks; those follow cert-manager mode, matching Contoller workflow gates.
- bootstrap_generate_playbook_repo - Deploy RHBK / Grafana / GitLab playbooks prefer the OpenShift route host over a poisoned standalone hostname.
- bootstrap_generate_playbook_repo - Gate RHBK Deploy present vs absent like ACM (wait operator / Keycloak CR / realm only on present; absent tears down CR → Subscription → OG → namespace without waiting for CSV).
- bootstrap_generate_playbook_repo - Generated ``ansible.cfg`` uses ``stdout_callback = default`` so bootstrap does not fail on removed ``community.general.yaml`` (community.general 12+).
- bootstrap_generate_playbook_repo - Keep ``configure-idm-acme-clusterissuer-tasks.yml`` gated with the IdM ACME playbook so Contoller JT ``playbooks/cert-manager/ado-configure-idm-acme-clusterissuer.yml`` is not left missing after mode-based playbook pruning.
- bootstrap_generate_playbook_repo - Keep cert-manager operator namespace (``cert-manager-operator``) distinct from the operand (``cert-manager``) so OperatorGroup create no longer 404s after creating only the operand ns.
- bootstrap_generate_playbook_repo - Load vault_rhbk.yml in NetBox/Grafana/BookStack/Quay/MinIO/Dev Hub OIDC (and related) playbooks so rhbk_admin_password resolves.
- bootstrap_generate_playbook_repo - Local component ordering expands nested Contoller workflows (e.g. ``ADO | RHBK Workflow`` → OAuth) so Deploy RHBK runs before Configure OAuth/RHBK; selection order is honored for ties and can be adjusted in the UI.
- bootstrap_generate_playbook_repo - Local component runs pass form ``htpasswd_idp_name`` / ``htpasswd_secret`` as extra vars so delete/add track the preflight Login button name even when group_vars are stale.
- bootstrap_generate_playbook_repo - Local no-AAP runner no longer forces ``-e state=present``, which overrode ``vars_openshift.yml`` and made Console Banner delete run as add.
- bootstrap_generate_playbook_repo - Mark ``ado-enable-realm-bootstrap`` as a non-recommended day-2 helper (Deploy RHBK / Deploy RHBK Realm already create and enable the realm).
- bootstrap_generate_playbook_repo - Never commit plaintext ``ado-preflight-*.json`` / ``ado-extra-vars.json`` / ``.vault_pass`` on git push; gitignore them and untrack if previously committed. Encrypted ``ado-preflight-*.json.vault.yml`` remains allowed.
- bootstrap_generate_playbook_repo - OpenShift Deploy RHBK playbook now ``set_fact``s ``install_rhbk_platform: openshift`` (and role vars) so stale ``vars_rhbk.yml`` cannot divert Contoller onto the standalone zip path.
- bootstrap_generate_playbook_repo - Seed ``ado-rhbk-api-pre_tasks.yml`` (and enable-realm / client-scope playbooks) into the Contoller project. Realm/client/mapper jobs imported that shared file but bootstrap never copied it, so Contoller failed with ``Unable to retrieve file contents``.
- bootstrap_generate_playbook_repo - Wait for cert-manager-webhook Deployment and Service endpoints (and retry ClusterIssuer create) before creating ``idm-acme``. Fresh Deploy no longer races ``no endpoints available for service cert-manager-webhook``.
- bootstrap_generate_playbook_repo - cert-manager playbook uses ``include_role`` with explicit operator/operand namespaces (``roles:`` params named ``name_space`` were ignored and only the operand NS existed).
- bootstrap_resolve_component - Always export ``name_space`` / ``app_namespace`` (and related) from the selected component registry so a flat inventory/group_vars value from another app (e.g. Virt ``openshift-cnv``) cannot make ACM uninstall/create in the wrong namespace.
- bootstrap_resolve_component - Always re-apply operator subscription identity vars (``operator_channel``, ``operator_name``, …) from the selected component so ACM ``release-2.x`` cannot leak into OpenShift Virtualization (or other operators) when Contoller inventory already defines ``operator_channel``.
- ci - Add ``infra.ado.grafana_upload_alerts`` to ``.ansible-lint`` ``mock_roles`` so standalone Grafana alert playbooks pass syntax-check.
- ci - Pin fakecloud to ``v0.44.10`` so Molecule jobs download the tagged release asset instead of querying GitHub's latest-release API.
- ci - Run ansible-lint offline so the certification checker does not try to install Automation Hub-only dependencies such as ``ansible.platform``.
- ci - Run the partner certification checker on pushes to ``main`` (including merges), on a daily schedule, or manually, instead of on every pull-request push.
- ci - Skip recursive include_role Jinja during production ansible-lint so the certification checker can complete.
- gitlab_install - Align bootstrap chart defaults with GitLab chart 10.3.2.
- gitlab_install - Align chart version fallback with supported ``10.3.2`` (operator rejects ``10.3.1``).
- grafana - Optional OpenShift or standalone install; content steps (datasources, folders, dashboards, alerts) run independently or config-only against an existing Grafana.
- grafana - Preflight tabs; datasources form (Prometheus URL/bearer and git/path JSON); General/root folder; Grafana API token/admin auth.
- grafana_create_datasource - Import datasource JSON from git/path; accept Grafana API token.
- grafana_upload_alerts - Admin basic auth fallback; clone git sources; independent Contoller JT.
- grafana_upload_dashboards - Always sanitize and truncate Grafana dashboard UIDs to 40 characters (schema-v2 ``metadata.name``). Long work-item names such as ``rhacs-vulnerability-dashboard.json__Security`` no longer cause ``uid too long, max 40 characters``. Also strip classic ``id`` from v2 upload specs.
- grafana_upload_dashboards - Enforce Grafana's 40-character UID limit with a hard regex slice. Jinja ``truncate(40)`` keeps a 5-character leeway, so names like ``rhacs-vulnerability-dashboard.json__Security`` (44 chars) were left unchanged and schema-v2 upload still returned ``uid too long, max 40 characters``.
- grafana_upload_dashboards - For Grafana root boards, omit ``folderUid`` / ``folderId`` entirely (empty uid and ``folderId: 0`` both returned ``folder not found`` on current Grafana).
- grafana_upload_dashboards - Remap all Prometheus datasource UIDs on ``pin``/``multi`` (Contoller exports use opaque UIDs, not only ``Openshift-*`` placeholders).
- grafana_upload_dashboards - Send schema-v2 dashboard ``spec`` as a JSON object (not a stringified YAML scalar) so Grafana accepts boards with ``elements`` (e.g. RHACS CVE report).
- grafana_upload_dashboards - Upload Grafana schema-v2 dashboards (``elements`` / no ``panels``) via ``/apis/dashboard.grafana.app/v2`` into the target folder (e.g. Security / RHACS boards).
- grafana_upload_dashboards - Upload root/General boards with ``folderId: 0`` instead of empty ``folderUid`` (Grafana returned ``folder not found``).
- install_rhbk - Fix cert-manager Certificate wait ``until`` using wrong register name (``ocp_rhbk_certificate_info`` vs ``install_rhbk_certificate_info``), which never saw Ready and retried until failure even when the Certificate was already issued.
- install_rhbk - Indent Jinja conditionals inside the standalone systemd unit ``content`` block so YAML parsers (sanity/ansible-lint) no longer treat ``{%`` as invalid tokens.
- install_rhbk - Use ``include_tasks`` (not static ``import_tasks``) for OpenShift vs standalone platform gates so Deploy RHBK on OpenShift no longer fails at playbook load on ``ansible.posix.firewalld`` from the unused standalone task file.
- install_rhbk - Wire correct native user-event metrics options (``event-metrics-user-enabled`` + optional feature ``user-event-metrics``) instead of the invalid ``event-metrics-user-events-enabled`` typo; do not enable them by default on RHBK ``stable-v26.0`` (crash-loop).
- netbox_oidc - Propagate the configured namespace and validate the existing installation prerequisite.
- ocp_absent_cleanup - Only finalize namespaces that are already ``Terminating`` (``ocp_absent_cleanup_finalize_only_terminating``, default true). Finalizing Active namespaces during every cleanup pass caused repeated ``Wait until finalized namespace is gone`` retry spam on absent.
- ocp_acm - Absent/heal hub cleanup now safeguards half-finished uninstalls: recreate the hub Namespace when MultiClusterHub is orphaned, force-remove ``multiclusterhub-operator-validating-webhook`` before DELETE (admission otherwise blocks delete when the webhook Service is gone), clear finalizers, and re-request delete so the wait loop does not sit with no ``deletionTimestamp``.
- ocp_acm - After MultiClusterHub create, wait for ``Running``, keep the ``console`` component enabled, and enable OpenShift Console plug-ins ``acm`` and ``mce`` by default so Fleet Management / All Clusters appears in the web console (operator-only install left the UI hidden).
- ocp_acm - Hard-fail when MultiClusterHub/MultiClusterEngine remain after hub cleanup (``Confirm … removed`` no longer uses ``failed_when: false``). Present previously continued and waited for Running on a Terminating MCH.
- ocp_acm - Harden ``state=absent`` to remove MultiClusterHub plus related hub objects (MultiClusterEngine, ClusterManager, ``local-cluster`` ManagedCluster), clear stuck uninstall finalizers, and drop known ACM validating webhooks whose backing Service is already gone.
- ocp_acm - On ``state=present``, detect Uninstalling MultiClusterHub / MultiClusterEngine and finish that uninstall first (``ocp_acm_heal_stuck_uninstall``, default true), ensure a missing ``local-cluster`` Namespace when the ManagedCluster exists, wait for MultiClusterHub ``Running``, and enable Fleet Management Console plug-ins ``acm`` and ``mce``.
- ocp_acm - Refuse ``state=present`` install/wait when MultiClusterHub is still Uninstalling/deleting; wait failure message now reports phase and deletionTimestamp.
- ocp_acm - Skip MultiClusterHub console-component patch when console is already enabled so present/workflow reruns stay idempotent (rewriting ``overrides.components`` without ``configOverrides`` was always ``changed`` and could bounce MCH back to Installing).
- ocp_acs - Omit empty storageClassName on PVC ensure so bound claims are not invalidated.
- ocp_acs - When storage is unset, omit storageClassName on PVC ensure instead of patching empty string onto bound claims. Do not invent a cluster default StorageClass.
- ocp_default_ingress_cert - Fix PEM normalize register/fail variable name mismatch (``ocp_default_ingress_cert_pem_normalize``) that always surfaced ``unknown openssl/normalize error``.
- ocp_devspaces - Do not overwrite ``custom_samples`` ConfigMap with the icon-less ``default_devfile_url`` sample when custom samples are set.
- ocp_devspaces - Drop ``#!/usr/bin/env python3`` shebang and executable bit from ``devworkspace_status_exporter.py`` so ansible-test sanity shebang checks pass (container runs ``python3 /app/exporter.py``).
- ocp_devspaces - Longer CSV wait and assert that reports only Dev Spaces CSV phases (not unrelated CSVs in openshift-operators).
- ocp_devspaces - Longer CheCluster wait and clearer failure when ``cheURL`` never appears.
- ocp_devspaces - Status exporter ClusterRole now force-converges with ``pods`` get/list and ``pods/exec`` get/create. Incomplete live ClusterRoles (devworkspaces-only) caused empty ``devworkspace_vscode_extension`` metrics even when the exporter Deployment was Running. ConfigMap updates force-replace and a pod template checksum annotation rolls the Deployment when the script changes.
- ocp_devspaces - Use the v2 networking hostname and share desired identity with readiness lookup.
- ocp_htpasswd_admin - After updating the htpasswd Secret, roll ``oauth-openshift`` and wait for the authentication operator. Contoller jobs were succeeding while console login kept failing because oauth pods never reloaded the new Secret (wait only ran when the OAuth IdP CR changed). Still uses Ansible ``password_hash('bcrypt')`` — no EE package install.
- ocp_htpasswd_admin - Default ``mappingMethod`` to ``add`` and refresh the existing HTPasswd IdP in place. Stale Identity ``htpasswd:admin`` with IdP ``htpasswd-admin`` caused console ``Could not create user`` under ``claim``. Also delete leftover ``htpasswd:<user>`` Identities when the IdP name is ``htpasswd-admin``.
- ocp_htpasswd_admin - Default ``state`` to ``present`` so local/no-AAP runs (which omit Contoller survey ``state``) no longer fail on ``state is undefined``.
- ocp_htpasswd_admin - Hash all HTPasswd users in one step so secondary users (for example ``chaddie``) are written into the secret, not only the first username.
- ocp_htpasswd_admin - Hash all htpasswd users via a single stdin Python job that emits the secret body and username list, avoiding Jinja ``| keys`` and looped ``set_fact`` drops that left only the first user (e.g. ``admin``) in the OpenShift secret.
- ocp_htpasswd_admin - Keep htpasswd hashing on system libcrypt (stdlib
  ``crypt`` or ctypes to libxcrypt) so Contoller EEs do not need a
  ``bcrypt`` Python package. Restores Python 3.13+ where stdlib ``crypt``
  was removed.
- ocp_htpasswd_admin - On ``state=absent``, remove only the configured Login button IdP; refuse when that name is missing but other HTPasswd IdPs exist (no more silent delete of default ``htpasswd-admin``).
- ocp_htpasswd_admin - Re-apply the OAuth HTPasswd IdP when ``fileData.name`` (secret) differs, not only when ``mappingMethod`` differs.
- ocp_htpasswd_admin - Replace invalid Jinja ``| keys`` filter in the hashed-user assert with ``dict2items`` so multi-user add/replace no longer fails after hashing.
- ocp_htpasswd_admin - Revert Contoller EE package install / ``htpasswd -nbB`` hashing. Restore Ansible ``password_hash('bcrypt')`` which the supported EE already provides; Contoller pods cannot install ``httpd-tools``.
- ocp_htpasswd_admin - ``state=absent`` now removes the IdP named in ``htpasswd_idp_name`` (and matching ``htpasswd_secret``), not the hardcoded ``htpasswd-admin`` fallback.
- ocp_minio - Build Service ports as real integers so the API rejects string ports no longer occur.
- ocp_minio - Create Service with native YAML and flat selector (fix empty-name patch / nested matchLabels).
- ocp_minio - Render Service ports as YAML integers with non-native templating.
- ocp_mtv - Default ``mtv-operator`` channel to ``release-v2.12`` (catalog current); ``release-v2.8`` caused ``ConstraintsNotSatisfiable`` when that channel is absent from redhat-operators.
- ocp_namespace - On ``present``, wait out and force-finalize a Terminating namespace before create (fixes OperatorGroup Forbidden ``NamespaceTerminating`` after cert-manager absent). On ``absent``, wait for deletion and finalize if stuck.
- ocp_namespace - On ``state=present``, sweep a Terminating namespace with ``ocp_absent_cleanup`` before create and fail if the namespace remains Terminating (avoids OperatorGroup Forbidden after reinstall).
- ocp_namespace - Prefer ``ocp_namespace_name`` over host fact ``name_space`` so dual-namespace installs (cert-manager-operator vs cert-manager) create the correct Namespace on Contoller.
- ocp_namespace - Shorten delete wait and always force-finalize when the namespace remains (common on ACM clusters where content is gone but discovery reports failure).
- ocp_oidc_auth - Require a CA for OpenShift Keycloak OIDC (prefer openshift-config-managed default-ingress-cert, then Keycloak TLS ca.crt/tls.crt). Set openID.ca so oauth-server can apply the IdP; fail the JT if no CA is found instead of succeeding with a hidden IdP.
- ocp_operator_subscription - On ``state=absent``, run the absent-cleanup gate with ``ocp_absent_cleanup_finalize=false`` so subscription uninstall sweeps OLM leftovers without deleting the namespace (``ocp_namespace`` owns that step).
- ocp_operator_subscription - ``state=absent`` now deletes the Subscription and matching ClusterServiceVersions (and related InstallPlans). Previously only the Subscription was removed, so the operator stayed in Installed Operators.
- ocp_operatorgroups - Default ``state`` to ``present`` so local/non-AAP component runs (which omit ``-e state=`` so vars-file deletes still work) no longer fail with ``'state' is undefined``.
- ocp_operatorgroups - On ``state=absent``, delete the OperatorGroup without requiring the namespace to still exist, wait for removal, and fix the already-absent debug message Jinja precedence that printed boolean false.
- ocp_quay - Handle an omitted OIDC issuer during fallback evaluation.
- ocp_quay - Resolve OIDC issuer without self-referencing an undefined ``ocp_quay_oidc_issuer_url`` fact.
- ocp_quay / ocp_minio - Apply cluster-resolved StorageClass into storage before assert.
- ocp_rhbk_client_secrets - Fix cluster admin Secret decode after rename so OIDC JTs can fall back when vault password is unset.
- ocp_virtualization - Set ``operator_deployment_pattern`` to ``hco-operator`` in component defaults and the deploy playbook seed so ``ocp_wait_operator`` matches the real HCO Deployment (CSV package ``kubevirt-hyperconverged`` is not a Deployment name).
- ocp_virtualization - ``state=absent`` deletes HyperConverged first, then subscription/OperatorGroup/namespace (same teardown order as ACM).
- ocp_virtualization_install - Wait for HyperConverged ``Available=True`` after the CSV reaches ``Succeeded``. A Succeeded CSV alone no longer marks virtualization ready.
- ocp_wait_operator - Require matching CSV ``status.phase == Succeeded`` before treating an operator as installed (avoids false success when only unrelated AllNamespaces CSVs are listed in the operator namespace).
- ocp_wait_operator - Skip wait tasks when ``state`` is not ``present`` via a portable ``when`` + ``block`` gate. Do not use ``meta: end_role`` (ansible-core 2.18+ only); older Execution Environments fail with ``invalid meta action requested: end_role`` even on ACM/Virt install (``state=present``).
- preflight / infra.ado - Remove hardcoded lab hostname defaults. Hostnames must come from the form, inventory, or survey — never silent defaults.
- rhbk_client_scope - Stop folding Keycloak mapper URLs across lines with ``>-`` after ``/client-scopes/``. YAML inserted a space before the scope UUID (``.../client-scopes/ <uuid>/...``), so Contoller failed with ``URL can't contain control characters``.
- rhbk_realm - Prefer ``ocp_rhbk_hostname`` for the admin API wait when ``install_rhbk_platform`` is ``openshift``.

Documentation Changes
---------------------

- Convert relative documentation links to absolute GitHub blob URLs under
  ``https://github.com/redhat-cop/infra.automation-development-office/blob/main/``
  in ``README.md`` and remaining collection docs.
- Update repository, documentation, homepage, and issues URLs from
  ``Automation-Development-Office/ado`` to
  ``redhat-cop/infra.automation-development-office`` in ``galaxy.yml``,
  ``README.md``, ``CODE_OF_CONDUCT.md``, and the Developers Guide.
- bootstrap_controller - Clarify Admin HTPasswd JT survey labels so ``htpasswd_action`` (add/replace/remove users) is distinct from ``state`` (present keeps the Login button, absent deletes the IdP).
- capsule_install - Documented firewall, DNS, and custom certificate generation tasks and DNS variables.
- docs - Restored collection README CI badges, certification badge, and role documentation links to ``redhat-cop/infra.automation-development-office``.
- install_rhbk - Document that login fail reason is the built-in ``error`` label on ``keycloak_user_events_total``.
- ocp_acm - Document robust absent/present behavior, heal flag, and Fleet Management console plug-in defaults.
- ocp_nfs_storage - Document NFS server/share/StorageClass variables and the preflight ``nfs_csi`` / ``nfs_server`` / ``nfs_share`` bootstrap contract so ADO Assistant README search finds NFS CSI install guidance.
- ocp_nfs_storage - Prefight UI now exposes NFS CSI under OpenShift Options; README already documents the JSON contract.

v1.4.0
======

Minor Changes
-------------

- Preflight bootstrap (ado-preflight-ui) — Replace the single git overwrite checkbox with a Git overrides section: optional ``group_vars/all/<env>``, job/workflow templates, or full re-clone wipe. Default (all unchecked) keeps the pod clone and only commits incremental bootstrap changes.
- ado-preflight-ui - Hub Collections multi-select for additional playbook collections; Galaxy credentials shown as tabs.
- ado-preflight-ui / bootstrap_controller - Restored Hub checkbox ``Install additional collections that are requirements for playbooks`` (``aap.hub_publish_preflight_collections``). Publishes baked preflight tarballs other than ``infra.ado`` into Hub validated content (kubernetes.core, redhat.openshift, community.general, community.grafana, grafana.grafana, ansible.controller, awx.awx, infra.controller_configuration, infra.aap_configuration, ansible.platform, ansible.hub, and containers.podman when present).
- bootstrap_generate_env_vars / bootstrap_generate_playbook_repo - ``ansible_dispatch_ignore_galaxy_cert`` defaults to false; preflight Galaxy tab checkbox opts in to ``GALAXY_IGNORE_CERTS`` and ``[galaxy] ignore_certs`` for lab self-signed Hub TLS.
- bootstrap_generate_playbook_repo - Add ``amazon.aws`` to Hub preflight publish catalog (``infra.ado`` declares it in ``galaxy.yml``; Contoller sync fails without it on Hub).
- bootstrap_generate_playbook_repo - Add ``ansible.posix``, ``community.hashi_vault``, and ``freeipa.ansible_freeipa`` to Hub publish manifest (preflight tarball + Contoller requirements when selected).
- bootstrap_generate_playbook_repo - Expand Hub preflight publish catalog with RH certified (``redhat.satellite``, ``redhat.rhel_idm``, ``redhat.rhel_system_roles``) and runtime deps (``infra.aap_utilities``, ``infra.rhacs_configuration``, ``ansible.utils``, ``community.kubernetes``) so Private Hub can be seeded when remotes are empty.
- galaxy.yml - Declare public Galaxy runtime collection dependencies (kubernetes.core, community.general, and others) with PEP 440 version ranges; document Automation Hub-only collections (including ``ansible.controller`` and ``hashicorp.vault``) excluded from ``dependencies`` per Red Hat collection publishing practice.
- install_rhbk - Standalone RHBK zip may come from HTTP/Satellite URL, git repo (cloned on the Keycloak host), or bootstrap ``files/`` upload; unpack always runs on the host.

Bugfixes
--------

- Accept HTTP 401 or 403 from the unauthenticated Automation Hub published-API probe in verify-automation-hub.sh. Red Hat Hub normally returns 401 without a token (auth required); 403 is tolerated because upstream proxies or API gateways sometimes classify missing credentials as Forbidden instead of Unauthorized. Either status still confirms the URL is reachable and not anonymously open, while 200 would indicate a misconfiguration and 5xx still fails the check. Galaxy remains 200-only; authenticated ansible.platform install remains the definitive Hub token test.
- Add ansible-galaxy install retries and a shared Molecule collections cache job to reduce Galaxy 504/resolver flakes in CI (matrix runs fully parallel; cache replaces throttling via max-parallel).
- Fix bindep platform profiles and always install libsystemd-dev and libkrb5-dev before ade pip requirements (avoids empty bindep match skipping the apt fallback; gssapi from ansible.eda needs krb5-config).
- Forward Automation Hub Galaxy server env vars through tox-ansible so sanity and unit jobs resolve certified collection dependencies from console.redhat.com.
- Install native build dependencies before tox ade install so sanity and unit jobs can resolve Hub collection Python requirements such as systemd-python.
- Preflight bootstrap (ado-preflight-ui) — Superseded by git.overrides (see git-overrides-preflight fragment). Incremental mode reuses the pod clone, preserves existing files unless a Git override scope is selected, and passes generate_env_vars_force=false by default.
- Remove unused variable from verify-automation-hub.sh so ansible-test shellcheck sanity passes.
- Retry ade install up to three times in tox commands_pre to absorb transient Galaxy dependency resolution failures under parallel CI matrix load.
- Use POSIX sh for ansible-galaxy-with-retry.sh so the ansible-lint container job can run collection install (Alpine image has no bash).
- ado-preflight-ui - Git Configuration collects Bitbucket username and validates it before bootstrap when Controller apply is enabled.
- bootstrap_controller - After ansible.hub staging upload succeeds, Pulp URI calls now use ``Authorization: Token`` with the same Hub/OAuth token that authenticated ``ah_namespace``/``ah_collection`` (or admin basic). Bearer Contoller OAuth was ignored on some gateways (``Authentication credentials were not provided``) when resolving pulp hrefs after upload.
- bootstrap_controller - Always force a Controller project sync during full bootstrap so preflight picks up git changes; only treat sync as fatal when the project had no prior successful update and git revision did not advance.
- bootstrap_controller - Empty Hub preflight collection name list publishes none (not every candidate).
- bootstrap_controller - Fix ``NameError: name 'false' is not defined`` when generating job templates. The force-overwrite flag is now emitted as Python ``True``/``False`` instead of JSON ``true``/``false``.
- bootstrap_controller - Fix project sync failure collection when loop results omit the ``skipped`` attribute.
- bootstrap_controller - Fix project sync failure collection when loop results omit the ``skipped`` attribute.
- bootstrap_controller - Fix pulp repository lookup URL for preflight Hub publish (YAML ``>-`` inserted a space before ``?name=``).
- bootstrap_controller - Fix undefined ``bootstrap_controller_hub_uri_oauth`` when publishing Hub collections (``set_fact``/block ``vars`` cannot reference sibling keys in the same task).
- bootstrap_controller - Hub Pulp ``ansible.builtin.uri`` calls use ``Authorization: Token`` (matching ``ansible.hub`` ``ah_token``) instead of ``Bearer``, and omit admin user/password when a Hub API token is set.
- bootstrap_controller - Hub namespace/publish now probes ansible.hub auth modes in order (Hub / Galaxy API token, Contoller OAuth, admin basic). ansible.hub hardcodes ``Authorization: Token``, so Contoller Gateway OAuth that only works as Bearer no longer hard-fails ``ah_namespace`` on AAP 2.6 gateways. Raw Pulp URI calls continue to use Contoller OAuth Bearer (or basic).
- bootstrap_controller - Hub publish/namespaces on gateway AAP now use Contoller OAuth (falling back to Hub API token only when OAuth is unset). The Hub User Access / Galaxy API token cannot authorize ``/api/galaxy/v3/namespaces/`` or collection upload on unified Gateway, which caused HTTP 401 during hub-only runs.
- bootstrap_controller - On hub-only runs, ensure the General Controller organization exists before Hub publish when Galaxy credentials or Hub EE Controller objects are enabled.
- bootstrap_controller - Project sync failure message no longer references hardcoded ``CKTEST-project``; uses the actual failing project name(s).
- bootstrap_controller - Put Hub pulp/content lookup URLs on one line so YAML ``>-`` does not insert spaces before ``?``/``&`` (breaks every preflight collection publish, not just repo lookup).
- bootstrap_controller - Skip Galaxy credential create/attach when Hub token is missing.
- bootstrap_controller - Skip ``infra.ado`` Hub publish when the version already exists in validated unless force is set; never force additional preflight collections; tolerate pulp promote 500 when version is already validated.
- bootstrap_controller - Split project sync tasks out of ``apply_aap_25_plus.yml`` to satisfy ansible-lint max-tasks and fix Hub publish URL line-length failures.
- bootstrap_controller - Stop falling back to Controller OAuth for Hub publish; require ``vault_galaxy_hub_token``.
- bootstrap_controller - Wait for collection versions to appear in Hub staging before pulp move; retry move and fall back to copy when Hub returns HTTP 500 (e.g. ``community.grafana`` promote race).
- bootstrap_controller — Honor ``bootstrap_controller_generate_aap_configs_force_job_workflows`` when generating ``configs/job_templates`` and ``configs/workflows`` (skip overwrite, prune, and in-place workflow rewrites when false).
- bootstrap_generate_env_vars - Admin HTPasswd preflight values now also land in ``vault_htpass_admin.yml`` / ``vars_htpass_admin.yml``, not only ``vault_openshift.yml``.
- bootstrap_generate_env_vars - Controller Source Control credentials for Bitbucket use ``git.username`` plus ``git.token`` instead of hardcoded ``oauth2``, which Bitbucket Server rejects during project sync.
- bootstrap_generate_env_vars - Galaxy credential URLs use Hub hostname; container registry credential can be created for EE push without enabling full Galaxy setup.
- bootstrap_generate_env_vars - Galaxy/Hub API credentials and org attachments are emitted only when ``galaxy_setup_enabled`` is true and ``galaxy_hub_token`` is non-empty; hub-only publish no longer pushes lab Galaxy creds.
- bootstrap_generate_env_vars - Stop mapping unused RHN org/activation key into standalone RHBK vars; prefer explicit ``standalone_zip_source``.
- bootstrap_generate_env_vars - Write ``vault_galaxy_hub_token`` from preflight only; Galaxy creds no longer default to Controller OAuth/password.
- bootstrap_generate_playbook_repo - HTPasswd bootstrap playbook loads OpenShift vault/vars so ``htpasswd_users`` and ``htpasswd_action`` are available to the JT.
- bootstrap_generate_playbook_repo - Stop listing ``infra.aap_utilities`` and ``infra.rhacs_configuration`` in Contoller ``collections/requirements.yml`` (Private Hub cannot resolve them and project sync fails). Bundle on the EE or publish to Hub when those JTs need them.
- bootstrap_generate_playbook_repo — Default ``bootstrap_generate_playbook_repo_force`` to false; preflight passes true only when Git override (all) is selected.
- ocp_htpasswd_admin - Fail fast when ``htpasswd_users`` is empty instead of skipping secret/OAuth creation and reporting success.
- rhbk_setup_mapper - Same folded-URL fix for Keycloak components query URLs.

Documentation Changes
---------------------

- ado-preflight-ui - Clarify that Contoller OAuth publishes to Hub on gateway AAP; Hub / Galaxy API token is for org Galaxy credentials and registry pulls.

v1.3.0
======

Major Changes
-------------

- install_aap - Stop creating a standalone ``AutomationController`` CR. Delegate ``present`` to ``infra.ado.aap_ocp_install`` (vendored ``infra.aap_utilities.aap_ocp_install``, same path as Contoller bootstrap) and ``absent`` to that role's ``reset_stale_database`` tasks. Callers must supply ``aap_ocp_install_*`` vars instead of the old ``ocp_aap26_*`` / ``AutomationController`` interface.

Minor Changes
-------------

- Add ado-aap-rhel-install-bootstrap.yml for non-OpenShift AAP installs.
- Remove vendored infra.ado.aap_ocp_install and aap_ocp_install_upstream; Contoller/playbooks call infra.ado.install_aap instead.
- Restore archived kube descheduler role tasks with install/remove KubeDescheduler CR support after operator subscription.
- Wire OpenShift Descheduler (`infra.ado.ocp_descheduler`) into bootstrap workflow, preflight configuration (instance name, interval, profiles), and env var generation.
- acs_report - Fetch Central export with ``ansible.builtin.get_url`` (no ``curl``). Parser runs via ``python3`` on the downloaded NDJSON so ``ee-supported-rhel9`` does not need extra OS packages.
- acs_report - Optional CVE enrichment via acs-cve-plugin (`acs-cve enrich-rows`) on RHACS scrubbed CSVs.
- acs_upload_policies - Apply policy JSON via infra.rhacs_configuration.rhacs_policy (export bundles via rhacs_policy_import); report configs still use Central REST.
- ado-preflight-ui - ACS config panel toggles for acs-cve-plugin enrichment when acs_report is selected.
- ado-preflight-ui - Apply OpenShift apps_domain to zabbix, dev_hub, bookstack, and netbox hostnames when components are selected.
- ado-preflight-ui - Copy Hub tarball to ``/workspace/infra-ado-*.tar.gz`` preserving the galaxy artifact name.
- ado-preflight-ui - Default Grafana OIDC on when Grafana and RHBK are both selected.
- ado-preflight-ui - Dev Hub form with GitLab token field; auto-populates from Git bootstrap token.
- ado-preflight-ui - Fix dev_hub route prefix (backstage-{instance}-rhdh) and define STALE_APP_HOSTNAME_DEFAULTS for lab hostname rewrites.
- bootstrap - Add rhel_system_roles meta-component that expands selected system roles into Contoller playbooks/JTs calling redhat.rhel_system_roles.* directly (no new infra.ado wrappers).
- bootstrap / preflight-ui - Register MinIO in component map, env generation, Controller JT, and preflight form (OIDC + console/API hostnames).
- bootstrap_controller - Add ``ADO | RHBK Workflow`` and ``ADO | Grafana Workflow`` sub-workflows; OpenShift workflow calls them instead of inline JT chains.
- bootstrap_controller - Added ADO Alt Routes Workflow and split route JTs/playbooks; OpenShift workflow ends with Print ADO Routes and optional Alt Routes Workflow.
- bootstrap_controller - Component sub-workflows (install then optional OIDC/SAML JT) for Quay, MinIO, Dev Hub, BookStack, NetBox, and Zabbix; OpenShift workflow uses workflow nodes instead of single deploy JTs.
- bootstrap_controller - Extend RHEL STIG job template survey with engine, RHEL 10 profile, and CaC remediate toggle.
- bootstrap_controller - Gate Grafana datasource/folder/dashboard/alternate-route job templates on preflight ``component_options.grafana``.
- bootstrap_controller - Gate RHBK LDAP group mapper JT on ``group_mapper`` / ``client_mappers`` options.
- bootstrap_controller - Grafana workflow adds optional JTs for OIDC, email/SMTP, datasource, folders, dashboards, and alternate route (preflight-gated).
- bootstrap_controller - Job template and workflow node **ADO | ACS RHACS Report (CVE Enriched)**.
- bootstrap_generate_env_vars - Add ``rhdh_client`` Keycloak preset for Developer Hub OIDC bootstrap.
- bootstrap_generate_env_vars - Emit ``stig_engine`` and ``rhel_stig_cac_remediate`` in generated ``vars_stig.yml``.
- bootstrap_generate_env_vars - Export dev_hub keycloak realm/client/instance and MinIO OIDC/storage vars from preflight JSON.
- bootstrap_generate_env_vars - Gate discover-routes print on checkbox; overlay writes vars_routes.yml from preflight route settings.
- bootstrap_generate_env_vars - Gate quay_oidc, minio_oidc, dev_hub_oidc, bookstack_oidc, netbox_oidc, and zabbix_saml on component_options selections.
- bootstrap_generate_env_vars - Wire ACS Central route hostname to ``ocp_acs_hostname``; OpenShift OAuth/LDAP IdP names from preflight ``openshift.oauth_rhbk`` / ``openshift.ldap_auth``.
- bootstrap_generate_playbook_repo - STIG hardening playbook branches on ``stig_engine`` (``cac`` vs ``system_role``).
- bootstrap_generate_playbook_repo - Split Grafana OpenShift playbooks into install, datasource, folders, and dashboards steps.
- bootstrap_resolve_component - Default ACS report CVE enrichment flags in components_defaults.
- capsule_install - Added storage configuration by reusing ``infra.ado.satellite_install`` ``storage_config`` with Capsule LVM variables.
- grafana / components_defaults - Enable Grafana Keycloak OIDC by default (``grafana-client``).
- grafana_install - Split install vs OIDC vs email configure scopes; patch existing Grafana CR for optional steps.
- infra.ado.ocp_alt_routes - Support default route labels, custom alternate route names, and ingress-controller router labels.
- infra.ado.ocp_quay, ocp_minio, ocp_dev_hub, bookstack_openshift, ocp_zabbix - Split install vs auth configure paths using install_scope flags.
- install_aap - Dispatch OpenShift installs to infra.aap_utilities.aap_ocp_install and RHEL installs to aap_setup_download / prepare / install; keep ADO Fernet reset and license attach helpers.
- install_elastic / components_defaults - Create lab Kibana/ES user (``kibana`` / ``eck_lab_password``) after cluster Ready.
- ocp_acs - Best-effort OpenShift OAuth auth provider after Central install.
- ocp_dev_hub - Mount ``rhdh-app-config`` via Backstage ``appConfig.configMaps`` and inject ``rhdh-secrets`` through ``extraEnvs.secrets`` (v1alpha5) so Keycloak OIDC actually loads. Omit empty GitLab integration / catalog URL blocks.
- ocp_minio - New MinIO OpenShift component (Deployment, PVC, API/console Routes, Keycloak OIDC console login with policy claim mapper).
- ocp_virtualization - Delegate VirtualMachine create to infra.openshift_virtualization_ops.vm_provision; keep Multus NAD and DataSource dataVolumeTemplates build in ADO.
- preflight / bootstrap_generate_env_vars - RHBK OpenShift TLS mode is selectable (edge default, cert-manager opt-in, or copy default ingress). cert-manager is never the default; issuer kind/name fields appear when cert-manager is chosen.
- preflight-ui - Alternate Routes tab with Print Alternate Routes, Add Alternate Route, and Add Ingress with Route sub-options; Discover Routes tab supports all routes, namespace list, or selected-app namespaces.
- preflight-ui - Expose RHEL System Roles under RHEL components with nested role checkboxes as config options.
- preflight-ui - Quay, MinIO, Dev Hub, BookStack, NetBox, and Zabbix get Grafana-style optional OIDC/SAML checkboxes; auto-enabled when RHBK is selected.
- rhel_stig_cac - Add DISA STIG Compliance-as-Code role for RHEL 8, 9, and 10 using OpenSCAP and scap-security-guide.

Bugfixes
--------

- Controller projects always use Hub for collections — git keeps only collections/requirements.yml (Hub names); vendored collection trees are never written to git and overwrite clears collections/ansible_collections.
- Fix OpenShift bootstrap playbooks for ACM and cert-manager so they
  create the namespace, OperatorGroup, and Subscription (and wait for the
  operator) before applying operands. ``Deploy cert-manager`` previously
  only ran ``ocp_routes``, which left IdM ACME ClusterIssuer failing on a
  missing webhook service; ``Deploy ACM`` previously applied MultiClusterHub
  without creating ``open-cluster-management``.
- Manifest maps preflight-ui/collections tarballs to Galaxy names for Hub publish and Controller requirements.
- OpenShift workflow - Cert/ingress then RHBK then OIDC then apps; wire DevSpaces and Web Terminal; converge to route print.
- Playbooks (quay, minio, grafana) - Remove duplicate RHBK secret fetch pre_tasks; roles own OIDC secret resolution. Add vars_rhbk.yml to Quay.
- Quay Keycloak login uses Database internal auth plus KEYCLOAK_LOGIN_CONFIG (AUTHENTICATION_TYPE OIDC crashes migration). RHBK realms default to enabled=true in rhbk_realm, components_defaults, env-var generation, and preflight UI so OIDC apps do not hit Realm not enabled.
- Quay Keycloak redirect URIs corrected to /oauth2/keycloak/callback paths and Quay config sets PREFERRED_URL_SCHEME=https plus EXTERNAL_TLS_TERMINATION so login no longer sends http redirect_uri (Invalid parameter redirect_uri).
- Quay supports Keycloak OIDC via KEYCLOAK_LOGIN_CONFIG; client secrets are fetched with ocp_rhbk_client_secrets. MinIO playbook pre-fetches secrets. OpenShift workflow adds BookStack, MinIO, and NetBox OIDC. RHBK client presets expanded (Quay, Dev Hub, Zabbix, Kibana, Kafka). Dev realm defaults to enabled; Dev Hub skips TLS verify for lab Keycloak; Zabbix admin password defaults to redhat123.
- RHBK API playbooks (realm, client, mapper, scopes, EntraID) — shared ``ado-rhbk-api-pre_tasks.yml`` drops OpenShift ``K8S_AUTH_*`` env, resolves standalone VM hostname/URL (``http://host:8080`` or HTTPS), and asserts admin API creds only.
- Update ACM default operator channel from ``release-2.14`` to
  ``release-2.17``. Current ``redhat-operators`` catalogs no longer publish
  2.14, which left the ACM Subscription in ``ResolutionFailed`` and
  ``ocp_wait_operator`` spinning on a missing CSV.
- aap_ocp_install - Force ``aap_ocp_install_reset_database=true`` in the bootstrap playbook (Contoller vars left it false so Fernet reset skipped).
- aap_ocp_install - Resolve component defaults in the AAP playbook so ``aap_ocp_install_reset_database=true`` actually runs; fail fast when gateway pods never become Ready (Fernet InvalidToken / 503).
- aap_ocp_install_upstream - Platform/Controller/EDA/Hub route readiness waits no longer require strict TLS verify + HTTP 200 only. Lab Contoller EEs often fail forever on self-signed apps certs or gateway 302 to /login; accept 200/302 (UI) and 200/401 (API) with validate_certs default false.
- bookstack_openshift - Do not fail deploy when pod exec for admin password reset is blocked (DevWorkspace webhook).
- bookstack_openshift - Resolve OIDC issuer into bookstack_openshift_oidc_issuer_resolved when Keycloak or RHBK issuer survey fields are empty.
- bookstack_openshift - Run MariaDB as UID/fsGroup 999 so PVC data dir is writable under anyuid on OpenShift (fixes CrashLoop Permission denied on /var/lib/mysql).
- bootstrap_controller - Apply workflow job templates in a separate Controller dispatch from job templates so a job template failure (for example transient DNS during async apply) no longer skips workflow node rebuild after ``destroy_current_nodes``.
- bootstrap_controller - Create Contoller organizations before Galaxy/Hub credentials exist, then attach ``galaxy_credentials`` after credential dispatch so org create does not fail with ``CKTEST-validated returned 0 items``.
- bootstrap_controller - Do not fail a successful Hub publish when Contoller Galaxy/org attach 401s. Galaxy attach only runs when ``galaxy_setup_enabled`` is true (not inferred from leftover git credential YAML).
- bootstrap_controller - Fix early config load gate to honor ``bootstrap_controller_apply_aap_configs`` (was referencing unset ``bootstrap_apply_aap_configs``).
- bootstrap_controller - Force infra.ado Hub collection update deletes the existing version (auto_approve false), waits for async delete, uploads to validated with auto_approve false (staging approve path is broken), and verifies the version exists on Hub before succeeding.
- bootstrap_controller - Hub-only publish no longer touches git or Controller project sync; requirements.yml and vendored-tree cleanup happen only on full bootstrap (generate_playbooks).
- bootstrap_controller - Hub-only runs force manual git before and after loading ``aap_config_vars.yml``; block playbook git-push when hub-only.
- bootstrap_controller - Implement preflight tarball publish to Hub validated: loop manifest tarballs from /opt/ado-collections, upload to staging, pulp-move to validated when missing (infra.ado excluded; already published separately).
- bootstrap_controller - Keep galaxy filename ``infra-ado-*.tar.gz`` for Hub upload (``ado-collection-artifact.tar.gz`` parsed wrong namespace/name).
- bootstrap_controller - On hub-only runs, skip Contoller org create from stale configs before Hub publish. Prefer ``vault_galaxy_hub_token`` for Hub API auth.
- bootstrap_controller - Pass ``galaxy_credentials`` when creating/updating organizations so Hub/Galaxy org attachments are not left unset on full bootstrap runs.
- bootstrap_controller - Prefix Hub publish task facts with ``bootstrap_controller_`` and fix line-length for pulp API URLs.
- bootstrap_controller - Publish the preflight pod tarball to Hub instead of rebuilding from extracted source (avoids artifact drift).
- bootstrap_controller - Remove staging upload debug task that crashed Jinja after a successful Hub import.
- bootstrap_controller - Resolve machine credential placeholder in job templates that used an inline Jinja ``default()`` expression (Register Host to Satellite, standalone GitLab/Grafana/RHBK) so AAP receives ``DEV-machine`` instead of raw template text.
- bootstrap_controller - Upload infra.ado to Hub ``staging`` then move into the target repository (e.g. ``validated``). Pipeline-approved repos reject direct uploads; prior direct-to-validated uploads returned changed but never appeared in Hub UI.
- bootstrap_controller - Verify promoted collection version via Hub Galaxy API before succeeding.
- bootstrap_generate_env_vars - Auto-enable ``rhbk_client_scopes`` when any OIDC app (Grafana, Quay, OpenShift OAuth, etc.) is selected; seed ``groups`` default scope on RHBK clients.
- bootstrap_generate_env_vars - Create ``<org>-RHEL-Inventory`` when Satellite ``satellite_client_tools`` is selected so ``Register Host to Satellite`` job templates resolve their inventory even when dynamic inventory is disabled. Dynamic inventory sources still attach only when dynamic inventory is enabled.
- bootstrap_generate_env_vars - Default ACS hostname from ``central.<apps_domain>`` when unset in preflight JSON.
- bootstrap_generate_env_vars - Emit Quay OIDC issuer from RHBK preflight; map Dev Hub ``gitlab_token`` into vault.
- bootstrap_generate_env_vars - Enable Grafana OIDC when RHBK is selected; stop overwriting OpenShift GitLab hostname with standalone VM defaults.
- bootstrap_generate_env_vars - Fix ``bootstrap_generate_env_vars_rhel_use_existing_inventory`` undefined error by evaluating RHEL inventory need after existing-inventory vars are resolved.
- bootstrap_generate_env_vars - Fix preflight vault encryption when ``ANSIBLE_VAULT_PASSWORD_FILE`` is set (``vault-ids default,default``) by unsetting the env var and passing ``--encrypt-vault-id default``.
- bootstrap_generate_env_vars - Hub-only and standalone AAP runs ignore ``git.auto_push: true`` in imported preflight JSON; generated ``aap_config_vars.yml`` always uses manual git mode.
- bootstrap_generate_env_vars - Keep Contoller org ``galaxy_credentials`` attachments when ``galaxy_setup_enabled`` is false so Contoller project sync can still pull Hub/Galaxy collections listed in ``collections/requirements.yml`` (e.g. ``community.grafana``). Credential object create/update remains gated by galaxy setup; attach_to_org list is always applied.
- bootstrap_generate_env_vars - Map preflight hostnames to dev_hub_hostname, zabbix_hostname, and bookstack_route_host during merge_component.
- bootstrap_generate_env_vars - Map vault aap_admin_password to aap_ocp_install_admin_password for license attach.
- bootstrap_generate_env_vars - Move preflight overlay Python out of inline shell heredoc; fixes ``Argument list too long`` (errno 7) on hub-only and full bootstrap runs.
- bootstrap_generate_env_vars - Normalize ``client_scope_name`` to ``groups``; merge federation LDAP settings into vault ``ldap_config``.
- bootstrap_generate_env_vars - On ocp-dev, stop pinning prod-only ``synology-nfs-csi`` when the cluster has no Synology CSI; roles now pick the cluster default StorageClass.
- bootstrap_generate_env_vars - Prefer RHBK realm over dev_hub keycloak_realm; wire keycloak hostname into dev_hub.
- bootstrap_generate_env_vars - Sanitize stale ACM operator channel release-2.14 to release-2.17.
- bootstrap_generate_env_vars - Seed vars_bookstack.yml and vars_netbox.yml with app_domain-aware defaults.
- bootstrap_generate_env_vars - Stop seeding hardcoded ``IDM_LDAP`` federation name; honor preflight ``federation_name`` (default ``LDAP``).
- bootstrap_generate_env_vars - Write devspaces hostname into ocp_devspaces_hostname.
- bootstrap_generate_env_vars - Write generate_playbook_repo_git_auth_mode into the generated aap_config_vars.yml so AAP job runs also use Bearer auth when the SCM tool is Bitbucket.
- bootstrap_generate_env_vars — map ``standalone_hostname`` to ``rhbk_hostname`` and ``install_rhbk_platform: rhel`` when RHBK standalone is selected; skip ``openshift_oidc_auth`` for standalone-only exports.
- bootstrap_generate_env_vars, netbox_oidc, bookstack, minio playbooks - Derive OIDC issuer and Keycloak realm from preflight RHBK hostname/realm (vars_rhbk.yml) instead of hardcoded prod ``rhlab`` defaults.
- bootstrap_generate_playbook_repo - Fail when Hub mode leaves vendored infra.ado in git or requirements.yml still uses type:dir; skip metadata stamp when Hub mode is on.
- bootstrap_generate_playbook_repo - GitLab playbook inherits openshift_default_storage_class for persistence.
- bootstrap_generate_playbook_repo - Include community.grafana in local vendored project requirements so Grafana datasource tasks resolve.
- bootstrap_generate_playbook_repo - Seed ``grafana_oidc`` and ``grafana_email`` playbooks so Controller job templates are not skipped when the matching playbook file is missing.
- bootstrap_generate_playbook_repo - Skip credential-store setup and use Authorization Bearer via Git http extraHeader when bootstrap_generate_playbook_repo_git_auth_mode is bearer (Bitbucket). Previously the role always wrote a git-credentials file with username:token@host which Bitbucket rejects.
- bootstrap_generate_playbook_repo - Stop listing infra.openshift_virtualization_ops and redhat.rhel_system_roles in Contoller collections/requirements.yml; they are not on public Galaxy and break project sync. Bundle them on the Contoller EE instead.
- bootstrap_resolve_component - Clear hard-coded Synology storage class default for GitLab OpenShift installs.
- bootstrap_resolve_component - Default CFK operator subscription namespace to confluent-operator-system.
- bootstrap_resolve_component - Default Grafana OIDC scopes include ``groups`` with standard ``role_map``.
- bootstrap_resolve_component - Export registry defaults when survey or extra_vars pass empty strings, not only when keys are undefined.
- bootstrap_resolve_component - Skip registry keys containing ``.`` before ``set_fact`` export (Ansible validates dynamic fact names before ``when``); fixes ``Deploy RHBK Realm`` and other JTs that only need API vars, not ``infra.ado.ocp_operatorgroups``.
- bootstrap_resolve_component - seed grafana_dev_prometheus_url before templating components_defaults, and stop referencing that play var inside the registry so non-grafana component deploys (ACM, descheduler, etc.) do not fail.
- bootstrap_resolve_component — add ``rhbk_standalone`` registry block without operator/OCP defaults.
- components_defaults / dev_hub - Install the RHDH operator Subscription into ``openshift-operators`` (reuse ``global-operators``) instead of a namespaced AllNamespaces OperatorGroup in ``rhdh``. The latter never produced an ``rhdh-operator`` CSV (Deploy Dev Hub timed out waiting for the operator).
- dev_hub - Subscribe to package ``rhdh`` on channel ``fast`` (old ``redhat-developer-hub-operator`` package is gone from the catalog).
- devspaces playbook - Print routes from openshift-devspaces app namespace.
- gitlab - Wait for CSV in ``gitlab-system`` (where Subscription installs), not empty ``gitlab`` namespace.
- gitlab OCP playbook - Install operator CR + Route (was routes-print only).
- gitlab_install - Chart 10.3.1 with lab external Postgres, Redis, and MinIO for chart 10.x (operator webhook rejects 9.x).
- gitlab_install - Configure chart 10.x registry object storage (separate S3 secret) so GitLab CR leaves Preparing/ConfigError.
- gitlab_install - Default chart version fallback ``10.3.0`` → ``9.5.0`` in the CR builder (matches components_defaults; chart 10 needs external DB).
- gitlab_install - Default chart version to ``10.3.0`` (GitLab operator v3.3 rejects ``9.7.0``; allowed: 10.3.0, 10.2.4, 10.1.6).
- gitlab_install / components_defaults - Pin OpenShift GitLab chart to ``9.5.0``. Chart ``10.x`` requires external Postgres, Redis, and object storage and left GitLab stuck in ``Preparing`` with an empty webservice.
- grafana_create_datasource - Probe Prometheus with ``/api/v1/query?query=up`` (reachable with ``cluster-monitoring-view``) instead of ``/api/v1/status/config``.
- grafana_create_datasource / grafana_install - OpenShift Grafana now defaults admin password (lab ``redhat123``) so datasource create does not assert on an empty password when UI left it blank.
- grafana_install - Always request the Keycloak ``groups`` scope and map ``groups[*]`` to Grafana roles (fixes ``IdP did not return a role attribute`` when the client scope was missing).
- grafana_install - Fix recursive Jinja loop fetching RHBK client secret; install JT no longer runs OIDC when only Deploy Grafana is selected.
- grafana_install - Fixed Jinja template error fetching RHBK client secret (replaced invalid ``.split()`` with ``regex_replace`` for realm parsing from OIDC issuer).
- grafana_install - Load ``vars_rhbk.yml`` in the Grafana deploy playbook and pass Keycloak host/realm explicitly into ``ocp_rhbk_client_secrets`` (fixes empty host/realm when ``grafana-client`` is configured in RHBK).
- grafana_install - Prefix role-local OIDC/email facts with ``grafana_install_``.
- install_aap - Fix recursive Jinja on aap_ocp_install_reset_delete_platform.
- install_aap - Prefix license/reset task facts with ``install_aap_``; replace ``ignore_errors`` with explicit ``failed_when``.
- install_dirsrv - Add missing LDIF bootstrap templates and fix aci-anon-read suffix variable.
- install_dirsrv - Break long ldap/dsconf commands and port list set_fact for ansible-lint line-length.
- install_dirsrv - Fix idempotent shell checks that used pipe ``|`` instead of ``||``, and correctly detect an existing suffix backend before create.
- install_dirsrv - Keep ldapsearch/ldapmodify shell commands on a single logical line so YAML folded more-indented newlines do not split argv (``-D: command not found`` on group membership).
- install_dirsrv - Treat suffix-backend already present or exists stdout as success on idempotent re-run.
- install_elastic - Build ECK CR definitions via set_fact to avoid YAML parse errors on integer fields.
- install_elastic - Create Elasticsearch + Kibana + Routes by default.
- install_rhbk - Default to OpenShift edge TLS (httpEnabled, no tlsSecret) so empty default-ingress PEMs no longer break Keycloak HTTPS with SSL UNEXPECTED_EOF. Validate ingress PEMs when copy mode is used; wait for cert-manager Certificate Ready when cert_manager=true.
- kafka_install - Build Kafka CR definitions via set_fact to avoid YAML parse errors on replica counts.
- kafka_install - Create Kafka CR with Route listeners by default.
- kafka_install - Default CFK external routes to ingress edge TLS (cert-manager ingress cert) instead of a self-signed CFK CA; patch operator routes after install.
- kafka_install - Emit CFK ``spec.image`` as ``{application, init}`` object (string image was rejected with 422 Unprocessable Entity).
- kafka_install - Grant CFK SA cluster Jobs RBAC (OLM ClusterRole omits ``batch/jobs`` and CrashLoops). Create ``KRaftController`` and wire ``spec.dependencies.kRaftController`` on the Kafka CR for CFK 3.x.
- kafka_install - KRaftController replicas as bare int (EE stringifies quoted Jinja).
- kafka_install - Probe confluent-operator Deployment across common operator namespaces.
- netbox_oidc - Fetch client secret via ocp_rhbk_client_secrets inside the role (same pattern as Quay/MinIO); remove duplicate playbook pre_tasks.
- netbox_oidc - Resolve issuer into netbox_oidc_issuer_resolved so survey netbox_oidc_issuer empty string cannot block asserts (extra_vars beat same-name set_fact).
- netbox_oidc - Surface Secret apply failures with readable errors; use server-side apply.
- oauth bootstrap playbook - Honor openshift_oidc_client_id from generated vars.
- ocp_acs - Auto-repair central-db password mismatch (reset DB Secret/PVC when Central CrashLoops on Postgres auth).
- ocp_acs - Default ``ocp_acs_reinstall`` to false so every run does not wipe central-db PVCs; when reinstall is on, wait for PVC deletion to finish.
- ocp_acs - Ensure ``central-pvc`` / ``central-db`` / ``central-db-backup`` PVCs exist before Central (claimName does not auto-create).
- ocp_acs - Use reencrypt Central Route with destinationCA from ``central-tls`` so browsers trust the cluster ingress / cert-manager lab cert instead of Central's self-signed passthrough certificate.
- ocp_acs / ocp_devspaces - Reduce excessive wait retries (~6 min max vs 20+).
- ocp_cert_manager - define role defaults and cert_manager_* aliases for ocp_cert_manager_* so Deploy cert-manager no longer fails on undefined ocp_cert_manager_root_ca_awspca_enabled; skip CA ClusterIssuer unless TLS material is present (IdM ACME uses its own playbook).
- ocp_component_route - Use resolved ``ocp_component_route_*`` facts in route tasks (leftover ``_route_namespace`` / ``_route_name`` caused Grafana Route JT to fail immediately).
- ocp_descheduler - Match real CSV name ``clusterkubedescheduleroperator`` (hyphenated substring never matched).
- ocp_descheduler - Set ``operator_deployment_pattern`` to ``descheduler-operator`` so CSV wait success is not followed by a Deployment name mismatch on the CSV package string.
- ocp_dev_hub - Fetch ``rhdh`` client secret via RHBK presets; fail when GitLab integration lacks token; load ``vars_rhbk.yml`` in bootstrap playbook.
- ocp_dev_hub - Fixed undefined ``ocp_dev_hub_keycloak_host`` by splitting hostname and issuer ``set_fact`` tasks.
- ocp_dev_hub - Use RHBK hostname vars; fail when OIDC client secret is missing.
- ocp_devspaces - Apply preflight hostname to CheCluster server/networking domain.
- ocp_discover_routes - Human-readable route table; OpenShift workflow ends on Print ADO Routes (always included when openshift is selected).
- ocp_htpasswd_admin - Only wait for authentication operator when OAuth was actually updated; require Available and not Degraded; longer retries.
- ocp_minio - Align Service selector with Deployment labels; wait for endpoints before exposing Routes.
- ocp_minio - Prefix role-local facts with ``ocp_minio_``; replace delete task ``ignore_errors`` with ``failed_when``.
- ocp_minio - Recreate Deployment when selector labels drift (immutable patch failure on re-run); treat empty minio_oidc_issuer as unset.
- ocp_minio - containerPort/service port as bare int (patch validation).
- ocp_oidc_auth - Prefix RHBK/OIDC resolution facts with ``ocp_oidc_auth_``.
- ocp_oidc_auth - Request only the ``groups`` extra scope for Keycloak/RHBK; strip ``openid`` (Keycloak rejects it and breaks login with ``invalid_scope``).
- ocp_operator_subscription / dev_hub - Delete stale ``redhat-developer-hub-operator-sub`` so OLM can resolve package ``rhdh``.
- ocp_operatorgroups - Fixed OperatorGroup create/reconcile tasks nested under a debug task ``when`` clause; restores valid task schema for ansible-lint.
- ocp_quay - Auto-select cluster default StorageClass when Quay storage is unset.
- ocp_quay - Bypass RHEL Postgres entrypoint ``chmod``/``chown`` that CrashLoops on Synology NFS root_squash; keep anyuid + initContainer.
- ocp_quay - Grant ``anyuid`` to default SA so Postgres (uid 26) can schedule under OpenShift restricted SCCs.
- ocp_quay - Prefix OIDC/storage resolution facts with ``ocp_quay_``; fix task key order.
- ocp_quay - Quay listens on HTTP ``8080`` in this install path: Service/Route target that port with ``edge`` TLS (not ``8443`` / reencrypt). Ensure ``pg_trgm``, ``SETUP_COMPLETE: true``, and disable ``FEATURE_ACTION_LOG_ROTATION`` unless archive storage is configured.
- ocp_quay - Treat empty ``quay_oidc_issuer_url`` as unset; require non-empty ``OIDC_SERVER`` before rendering Keycloak login config.
- ocp_rhbk_client_secrets - Prefer host vars (ocp_rhbk_realm, rhbk_realm, ocp_rhbk_hostname) over components_defaults rhlab fallback; fetch Keycloak admin password from keycloak-admin-creds when vault unset.
- ocp_rhbk_client_secrets - Treat empty-string hostname/realm vars as unset so registry defaults apply.
- ocp_wait_operator - Also match hyphen-stripped CSV names and emit clearer timeout guidance (namespace + pattern + CSVs present).
- ocp_zabbix - Apply multi-document MariaDB/Zabbix manifests with ``from_yaml_all`` so Deployment+Service templates no longer fail ``from_yaml`` at the second ``---``.
- ocp_zabbix - DB init Job loads ``create.sql.gz`` from current ubuntu server images (old ``server.sql.gz`` split is gone); delete failed Job before recreate.
- ocp_zabbix - Enable SAML SSO flag via API when RHBK is selected (Zabbix uses SAML, not OIDC, for login).
- ocp_zabbix - Treat already-changed Admin password as success during reset.
- quay playbook - Run ocp_quay (PVC/DB/Deployment/Service/Route); was OLM only.
- rhbk_client_scope - Wire ``groups`` client scope JT into RHBK workflow; attach default scope to OIDC clients (fixes Grafana missing ``groups`` claim in dev).
- rhbk_manage_federation - Resolve ``rhbk_federation_name`` from preflight ``federation_name`` instead of a fixed IdM label.
- rhbk_realm - Wait for Keycloak HTTPS ``/realms/master`` before realm API; ``validate_certs`` defaults false (lab/self-signed ingress).
- rhbk_setup_mapper - Seed IdM LDAP user-attribute mappers matching prod; honor preflight ``federation_name`` as ``rhbk_federation_name``.

Documentation Changes
---------------------

- README - Document ``infra.ado.ocp_dev_hub`` and ``infra.ado.ocp_zabbix`` in the role documentation table.
- ocp_dev_hub - Add role README (``docs/templates/role_readme_format_template.md``) required for Hub collection import.
- ocp_zabbix - Add role README (``docs/templates/role_readme_format_template.md``) required for Hub collection import.

v1.2.0
======

Major Changes
-------------

- Grafana datasources: ``Openshift-Prod`` defaults to ``thanos-querier``
  (platform + user-workload metrics). ``Openshift-Dev`` uses a remote
  Prometheus URL with ``bearer_token`` / ``bearer_token_secret``.
  ``ocp_cert_manager`` now creates ServiceMonitors with ``honorLabels``
  so certificate expiry dashboards see real Certificate namespaces.

Minor Changes
-------------

- Add OpenShift Grafana dashboards for Keycloak metrics (community 10441), K8S overview (community 15661), and cert-manager certificate expiry with main ADO cert coverage for prod and dev under ``templates/Openshift/dashboards/``.
- BookStack OIDC trusts lab CA via ConfigMap + initContainer (fixes cURL error 60).
- BookStack admin password reset and OIDC (Keycloak RHLAB) env wiring in ``bookstack_openshift``.
- Default AAP OpenShift install version is now 2.7.
- Grafana seed templates - add OpenShift Prod and Dev cluster resource overview dashboards (node CPU/memory ratios, namespace pod table, network, storage, summary stats) under ``templates/Openshift/dashboards/``.
- Grafana: deploy OpenshiftProd and OpenshiftDev folders (pinned datasources) plus
  optional shared Openshift folder with a K8S Prod/Dev dropdown
  (grafana_group_cluster_dashboards). Datasources Openshift-Prod/Dev use thanos-querier.
- Hub EE push accepts Contoller OAuth token (unused+token) for local podman without admin password.
- NetBox OIDC role + Contoller JT to wire Helm NetBox to Keycloak RHLAB.
- OpenShift Dev: document/enable cert-manager Operator + ServiceMonitors for
  Grafana expiry dashboards; Openshift-Dev datasource should use Dev
  thanos-querier (not prometheus-k8s alone) so user-workload metrics appear.
  Dev Keycloak dashboard points at Prod RHBK Micrometer metrics (shared IdP).
- Process rule: prefer ADO roles + bootstrap Contoller JTs before ad-hoc API scripts.
- RHBK manage-client bootstrap passes standard OIDC client fields from ``rhbk_clients``.
- RHBK standalone Contoller JT + playbook seed; preflight option ``standalone``.
- Release infra.ado 1.1.1 for preflight (hub-only always creates General Contoller org; Hub EE attaches Container Registry credential).
- Release infra.ado 1.1.2 for preflight overlays and collection tarball.
- ``grafana_create_datasource`` now creates a list of Prometheus datasources (default ``Openshift-Prod`` / ``Openshift-Dev``), ensures the monitoring SA token Secret, and the dashboards playbook also runs datasource + folder create. Folder/dashboard upload uses ``community.grafana`` with admin basic-auth fallback so Deploy Grafana works without a pre-made API key.
- aap_ocp_install - Accept AAP 2.7 operator channels (``stable-2.7`` / ``stable-2.7-cluster-scoped``) in addition to 2.5 and 2.6.
- aap_ocp_install - Support optional ``aap_ocp_install_rhn_subscription_id`` and service-account ``client_id``/``client_secret`` for license attach; auto-select an Ansible Automation Platform pool when subscription id is omitted.
- aap_ocp_install / bootstrap_controller - Support ``aap_ocp_install_license_only`` to skip operator install and only run ``activate_license.yml``.
- acs_report - New role to generate RHACS vulnerability reports from Central workload export (``raw`` / ``rhsource`` / ``age`` / ``all``), with ``--all`` / ``--rhsre`` / ``--sev`` / ``--component`` scope options and companion summary JSON.
- acs_report - Ship a Grafana posture dashboard with Red Hat-source and raw component bar charts, unique CVE / Critical / Important totals, daily discovery inflow, and cumulative backlog growth.
- acs_report - Ship sample Grafana dashboard ``files/grafana/rhacs-vulnerability-overview.json`` seeded from scrubbed prod Critical+Important+Fixable component counts.
- ado-preflight-ui - Add AAP 2.7 to the version selector and pass it through to bootstrap.
- ado-preflight-ui - Checking Hub collection publish, Push EE, or Run Hub updates only also enables Galaxy/registry credential setup so org + pull auth are ready for Contoller.
- ado-preflight-ui - Test AAP connection (controller ping) before bootstrap
  ansible when configuring an existing Contoller.
- bookstack_openshift - New role to deploy BookStack + MariaDB on OpenShift (PVC, Route, Contoller JT).
- bootstrap - Add AWS platform umbrella selection via preflight
  ``components``, ``component_apps.aws``, and ``component_options.aws``.
  ``ec2_ami_copy`` remains the first app with shared ``vault_aws.yml`` and
  ``vars_aws.yml`` credentials. Legacy standalone ``ec2_ami_copy`` preflight
  selection remains supported.
- bootstrap - Add ``ado-copy-ami-bootstrap`` playbook, job template, and
  ``vars_ec2_ami_copy`` generation for ``infra.ado.ec2_ami_copy`` cross-region
  AMI copies.
- bootstrap - Add shared ``vault_aws.yml`` / ``vars_aws.yml`` credentials for
  all AWS bootstrap consumers (``ec2_ami_copy``, cert-manager AWS PCA, and
  future modules).
- bootstrap - Seed playbook ``playbooks/acs/ado-acs-report.yml`` and Controller JT ``ADO | ACS RHACS Vulnerability Report``.
- bootstrap_controller - Accept ``aap_version: 27`` and use the AAP 2.5+ gateway apply path.
- bootstrap_controller - Add RHACS report job templates (survey, rhsource, raw, age) and ``ADO | ACS RHACS Report Workflow`` when the ``acs_report`` option is selected.
- bootstrap_controller - Add ``ADO | IdM Manage AD Trust`` job template for ``idm_ad_trust_install``.
- bootstrap_controller - Add ``ADO | Satellite Keycloak OIDC`` job template for ``satellite_oidc``.
- bootstrap_generate_env_vars - Allow Patching to reuse an existing AAP inventory via ``component_config.patching.inventory_mode: existing`` and ``inventory_name`` instead of creating ``<org>-RHEL-Inventory``.
- bootstrap_generate_env_vars - Also imply the ``compliance`` component from ``component_options.rhel`` the same way ``stig`` is implied.
- bootstrap_generate_env_vars - Expand ACS ``component_options`` into playbook/JT selectors (same pattern as Satellite/IdM).
- bootstrap_generate_env_vars - Honor Galaxy credential ``order`` (1 = first in org Galaxy search list); emit optional non-admin Contoller user from Galaxy tab.
- bootstrap_generate_env_vars - Honor ``pre_installs.install_aap`` and map component ``replicas`` (including AAP controller replicas) from preflight form values.
- bootstrap_generate_env_vars - Honor preflight AAP version ``2.7`` / ``27`` for generated ``aap_version``, operator channel, and EE image.
- bootstrap_generate_env_vars - Honor preflight ``component_config.aap.operator_scope`` (``all_namespaces`` or ``namespaced``) when choosing the AAP operator channel; explicit ``operator_channel`` still wins.
- bootstrap_generate_env_vars - Overlay IdM AD trust vars/vault secrets from preflight and create IdM inventory when AD Trust is selected.
- bootstrap_generate_env_vars - Stage a selected RHBK standalone zip into
  ``files/`` and set ``rhbk_standalone_zip`` to the playbook-relative path
  so AAP can copy it from the controller/EE.
- bootstrap_generate_env_vars - When preflight Galaxy setup is enabled, emit Galaxy/Hub API Token and Container Registry credentials (and org ``galaxy_credentials`` attach) using General Contoller admin/OAuth fallbacks when tokens are empty — same pattern as Hub EE push.
- bootstrap_generate_env_vars / preflight - Pass hostname, vaulted RHN password, optional subscription id, and admin credentials through to license activation.
- bootstrap_generate_playbook_repo - AD trust bootstrap playbook loads ``vars_idm.yml``/``vault_idm.yml`` and targets the IdM inventory.
- bootstrap_generate_playbook_repo - Add Satellite Keycloak OIDC bootstrap playbook.
- bootstrap_generate_playbook_repo - Added ``community.grafana`` and ``grafana.grafana`` to generated collection requirements.
- bootstrap_generate_playbook_repo - Default generated ``collections/requirements.yml`` pin for ``infra.ado`` is ``1.0.3``.
- bootstrap_generate_playbook_repo - Seed Grafana dashboard templates under
  ``playbook_repo_seed/templates/`` for copy-out: Openshift ``*.json.j2``
  dashboards and the RHACS vulnerability overview sample
  (``templates/RHACS/dashboards/rhacs-vulnerability-overview.json``).
- bootstrap_generate_playbook_repo / bootstrap_controller - Wire BookStack playbook and JT seed; selectable as ``bookstack`` OpenShift app.
- bootstrap_resolve_component - Register ``bookstack`` component defaults.
- bootstrap_resolve_component / preflight - Default ``grafana_folders`` now points at ``templates/Openshift`` and ``templates/RHACS``.
- capsule_install - Added RHSM subscription tasks to register Capsule hosts with Satellite and enable required repositories.
- capsule_install - Added ``capsule_install_setup_insights`` (default ``false``) to control Insights setup during Capsule registration.
- capsule_install - Added skeleton role structure for Red Hat Satellite Capsule installation.
- capsule_install - Updated role defaults and main task flow to support preliminary check and RHSM registration.
- ci - Start fakecloud in the Molecule pipeline for scenarios listed in
  ``extensions/molecule/fakecloud_scenarios.txt`` so AWS API integration
  tests (``integration_ec2_ami_copy`` and
  ``integration_ec2_ami_copy_keep_name`` for ``infra.ado.ec2_ami_copy``)
  run without real cloud credentials.
- collections - Declare ``redhat.rhel_idm`` in collection requirements and playbook repo seed/template so IdM server/client/replica jobs can install the certified collection from Automation Hub.
- docs - Expanded Hub recovery/permanence runbook for shared-Postgres LWLock failures.
- idm_ad_trust - Replaced ``ipa`` CLI / ``ansible.builtin`` shell wrappers with ``redhat.rhel_idm`` modules (``ipatrust``, ``ipadnsforwardzone``, ``ipaidrange``, ``ipagroup``, ``ipasudorule``). Service start/restart (smb, named, sssd) now uses ``infra.ado.rhel_services_management``. OS-level steps (packages, firewalld, crypto policy, ``ipa-adtrust-install``) remain builtin where no collection role exists.
- infra.ado - Preflight/bootstrap support for Grafana multi-folder git sources (json vs json.j2), alerts upload, ACS policies-from-git, RHBK multi-client + LDAP federation/mapper wiring, AAP license manifest/RHN activation, banner survey fields, and htpasswd add/replace/remove.
- infra.ado.ec2_ami_copy - Added ``integration_ec2_ami_copy_keep_name``
  Molecule scenario to exercise copies that omit ``name``.
- infra.ado.ec2_ami_copy - ``name`` is optional; omit it to reuse the source
  AMI name, or set it to rename the copied AMI in the destination region.
- infra.ado.idm_ad_trust - New role and playbook to establish two-way IdM/AD trust, DNS forward zone, ID range fixes, and AD external group mapping for SSH/sudo.
- infra.ado.idm_ad_trust - Run ``ipa-adtrust-install``, ensure SMB, open ``freeipa-trust`` firewall, disable DNSSEC validation for AD forward zones, re-kinit after AD trust install, and support one-way or two-way trusts.
- infra.ado.idm_ad_trust - Update default AD forest targets to ``ad.lab`` / ``adwindows.ad.lab`` / ``192.168.0.61``.
- infra.ado.ocp_aap_hub_harden - New role to pin Hub to single replicas, single gunicorn workers, and install maintenance CronJob against core_apiappstatus LWLock storms.
- infra.ado.ocp_aap_hub_harden - Pin Hub to dedicated unmanaged Postgres secret and vacuum ``core_apiappstatus`` on ``aap-hub-dedicated-postgres-0`` instead of shared Controller Postgres.
- infra.ado.ocp_devspaces - Configurable disable of getting-started samples, default workspace image/devfile URL, and dashboard image overrides (CLI/preflight).
- infra.ado.rhbk_client - Run Keycloak API tasks with ``connection: local`` so
  client create works when the play targets a remote Satellite host.
- infra.ado.satellite_oidc - Create Keycloak client ``ado-satellite`` in realm ``rhlab`` with ``infra.ado.rhbk_client``, fetch the client secret, enable Foreman Keycloak on Satellite, and apply OIDC login-delegation settings.
- install_gitlab / install_grafana — standalone RHEL Omnibus GitLab CE/EE and Grafana roles with Contoller bootstrap playbooks and job templates (``ado-install-*-standalone-bootstrap``), airgap RPM path/url vars, and gitlab_standalone / grafana_standalone component wiring.
- install_gitlab / preflight - Optional ``tls.crt`` / ``tls.key`` PEMs and
  optional RHN org + activation key for standalone URL installs. GitLab
  playbook waits for SSH and pings the host before gathering facts.
- install_rhbk — optional standalone HTTPS on port 8443 using the same tls_crt/tls_key PEM pattern as the OpenShift RHBK path (install_rhbk_standalone_https_enabled).
- preflight - ACS form option to deploy RHACS vulnerability report job templates and workflow.
- preflight - Add a visible ``Attach AAP license`` card on Install / Run (manifest or RHN list+attach), including license-only attach for an existing AAP without reinstalling the operator.
- preflight UI - Core Environment and Pre-installs are top-level tabs; Agent install-config lives under Pre-installs only.
- satellite / idm - Default component options are empty; Satellite dynamic inventory is an explicit selectable option.

Removed Features (previously deprecated)
----------------------------------------

- infra.ado.vpn_access - Removed from the collection; lab VPN / IdM user provisioning lives outside ADO under lab-tools (Add user to lab).

Bugfixes
--------

- AAP license attach now posts ``subscriptions_client_id`` /
  ``subscriptions_username`` field names expected by Controller
  ``/config/subscriptions/`` (bare ``client_id`` / ``username`` caused
  ``Missing subscription credentials`` on AAP 2.5+). Portal-style
  values in client ID (e.g. ``rh-ee-*``) are remapped to username/password.
- Clarify AAP license RHN attach failures for ``Missing subscription credentials`` (AAP 2.5+ service account client_id/client_secret) and send the subscriptions POST body as a proper JSON object.
- Grafana OpenShift dashboards: remove broken ``origin_prometheus`` filters from
  K8S views (caused systemic No data on OCP), replace Keycloak SPI dashboards
  with RHBK Micrometer metrics (``jvm_*`` / ``http_server_*``), and make
  cert-manager expiry tiles show 0 instead of No data for empty windows.
- Prefer General-tab AAP hostname and admin password for license-only attach instead of stale Install AAP ``component_config.aap.hostname`` values, and surface RHN subscription-list HTTP errors without dumping secrets.
- aap_ocp_install - Detect an existing cluster-scoped AAP operator and skip creating another OperatorGroup/Subscription so a second namespace does not cause InterOperatorGroupOwnerConflict or break the original install.
- aap_ocp_install - Fail when the requested AAP version differs from an existing cluster-scoped operator instead of installing a second operator.
- aap_ocp_install - Prefer the operator-discovered controller/platform route host for RHN license attach instead of only the preflight hostname hint.
- aap_ocp_install - RHN license activation now lists subscriptions and POSTs ``/config/attach/`` with a ``subscription_id`` instead of only posting username/password to ``/config/`` (which left new AAP installs on the subscription wizard).
- aap_ocp_install_upstream - On AAP 2.5+ unified installs, Hub no longer gets a dedicated ``*-hub`` Route (API is on the platform gateway). Stop failing the install waiting for that missing route; fall back to the gateway URL for Hub readiness checks so license activation can run.
- acs_report - Use ``#!/usr/bin/env bash`` on ``rhacs-report.sh`` (mode 0644
  in git). ansible-test allows that shebang on non-module files and
  shellcheck needs one; the role copies the script to ``/tmp`` as 0755.
- ado-preflight-ui - Remove playbook-adjacent vendored ``infra.ado`` before bootstrap so Ansible cannot shadow the staged collection tarball.
- ado-preflight-ui - Restore Logs/Events search, fix DevSpaces config crash when defaults are missing, and replace Pre-installs with Install AAP / OpenShift agent checkbox cards.
- bookstack_openshift - Use ``mariadb-admin`` probes, port 8080, PVC initContainer/subPaths, and integer Service/Deployment fields for Contoller EE.
- bootstrap_controller - After project apply, set ``scm_url`` / ``scm_branch``
  on existing Contoller projects so a new git branch is used before sync.
- bootstrap_controller - Always create Contoller organizations on hub-update-only runs, and ensure the General organization exists even when generated configs list a different org.
- bootstrap_controller - Clarify Hub collection IndexError warning as "version already present" and point operators at Force update or galaxy.yml bump.
- bootstrap_controller - Contoller project create no longer sets ``update_project: true`` (sync-on-create), which failed during ``install_collections`` when Hub lacked ``infra.ado``. Projects are created first, then synced with actionable Hub guidance on failure.
- bootstrap_controller - Contoller project sync failure guidance no longer implies Hub republish is required; Hub update remains optional when ``infra.ado`` is already present.
- bootstrap_controller - Contoller project sync failures now fail with guidance to publish ``infra.ado`` to AAP Hub when ``collections/requirements.yml`` cannot be satisfied.
- bootstrap_controller - Do not create RHEL Compliance/STIG job templates from a Patching-only selection. Selecting ``rhel`` now only maps the patch-host job template; compliance and STIG require those components (or RHEL options) explicitly.
- bootstrap_controller - Do not create an org-scoped ``Ansible Galaxy``
  credential. AAP ships that name as a platform-global credential; attach it
  to the organization instead of failing with already-exists.
- bootstrap_controller - Filter Satellite/IdM job templates and workflows by option keys (for example ``satellite_client_tools``, ``idm_client_tools``) instead of the coarse ``satellite``/``idm`` components.
- bootstrap_controller - Hub EE push no longer hard-fails hub-update-only runs when the preflight/Dev Spaces host has no podman/docker; skips with guidance (optional skopeo path when pull-from-remote is enabled).
- bootstrap_controller - Install AAP during bootstrap when ``install_aap`` is set, without requiring the AAP platform component or Using AAP / Contoller API fields.
- bootstrap_controller - On hub-update-only runs, apply Galaxy/Hub API Token credentials and org attach before ``meta: end_host`` so Hub + Galaxy (or either alone) both work when selected.
- bootstrap_controller - On hub-update-only runs, reload ``aap_config_vars.yml`` before applying Galaxy/Hub credentials so stale ``configs/controller`` does not skip credential create/attach when Galaxy setup is enabled.
- bootstrap_controller - Prefer generated ``controller_bootstrap_environment_choices`` over the old fixed survey list.
- bootstrap_controller - Resolve AAP install flags when preflight omits ``component_config.aap`` or ``pre_installs.aap`` (single-component bootstrap tests).
- bootstrap_controller - Resolve OpenShift API host/token with empty-string defaults so Install AAP can build a kubeconfig when ``token`` is blank in another vars file.
- bootstrap_controller - Skip create/update when an execution environment
  already exists (or GET returns 403). Org tokens can use a global EE on
  job templates but cannot PATCH it; bootstrap continues with projects and
  JTs.
- bootstrap_controller - Skip generating AAP job templates when their playbook was not generated into the project, preventing ``Playbook not found for project`` failures.
- bootstrap_controller - fix license-only AAP attach failing with recursive template loop when ``include_role`` vars defaulted ``aap_ocp_install_platform`` onto itself (license-only skips the platform set_fact).
- bootstrap_controller / push_hub_ee - Create Contoller Container Registry credential from General admin/token and attach it to the Contoller EE so Hub image pulls no longer ImagePullBackOff with invalid username/password.
- bootstrap_controller / push_hub_ee - Split Hub EE org/cred ``set_fact`` so Contoller org resolve no longer fails with ``bootstrap_controller_hub_ee_org is undefined`` (same-task self-reference).
- bootstrap_controller push_hub_ee - Lowercase Hub EE repository names for registry API compatibility (``ADO-ee`` → ``ado-ee``) and surface skopeo stderr on push failure instead of a censored ``no_log`` failure.
- bootstrap_generate_env_vars - Always create ``<org>-RHEL-Inventory`` when the Patching group is selected, and accept managed hosts from ``component_config.patching`` as well as ``component_config.rhel``.
- bootstrap_generate_env_vars - Create Satellite/IdM server inventories only when server/capsule/replica install options are selected.
- bootstrap_generate_env_vars - Emit survey ``environment_choices`` from the primary preflight environment plus optional ``additional_environments`` (no hardcoded ``dev/test/preprod/prod`` list when generating from preflight).
- bootstrap_generate_env_vars - Empty Satellite/IdM option lists no longer expand to all install playbooks/JTs.
- bootstrap_generate_env_vars - Expand Satellite and IdM ``component_options`` into playbook/JT selectors so client-only selections no longer copy every Satellite/IdM bootstrap playbook and job template.
- bootstrap_generate_env_vars - Generate ``ipaclient_*`` and ``ipaadmin_password`` mappings in IdM vars/vault so client-only bootstrap can join hosts without DNS autodiscovery.
- bootstrap_generate_env_vars - Generate ``vars_aap.yml`` for Install AAP even when AAP is not a selected component, and skip Contoller API access for that install-only run.
- bootstrap_generate_env_vars - Treat ``idm`` under ``component_apps.patching`` as IdM selected so ``<org>-IDM-Inventory`` is generated for patching-only runs.
- bootstrap_generate_env_vars - Write ``rhel_sat_reg_*`` and ``satellite_activation_key`` from preflight ``component_config.satellite.activation_key`` (client host registration) instead of reusing the RHN activation key.
- bootstrap_generate_env_vars - Write shared ``vault_aws.yml`` credentials without overwriting them when processing the ``aws`` component overlay.
- bootstrap_generate_env_vars / bootstrap_controller - license-only and ``attach_aap_license`` preflight runs synthesize ``component_config.aap`` and treat attach as install-during-bootstrap so attach no longer skips with empty ``component_config``.
- bootstrap_generate_playbook_repo - Generated ``collections/requirements.yml`` no longer pins ``infra.ado``; Contoller/Hub installs latest unless an explicit version override is set.
- bootstrap_generate_playbook_repo - IdM manage-client playbook now loads ``vars_idm.yml``/``vault_idm.yml``, maps bootstrap IdM settings to ``redhat.rhel_idm.ipaclient`` inputs, and runs with ``become``.
- bootstrap_generate_playbook_repo - Target RHEL/IdM client playbooks at ``hosts: all`` so they run against the dedicated RHEL inventory without requiring a missing ``rhel_servers``/``ipaclients`` group.
- bootstrap_generate_playbook_repo - When Hub collection update is not requested, omit ``collections/requirements.yml`` (so Contoller project sync does not call Galaxy/Hub) and vendor ``infra.ado`` into the git project for job runtime.
- bootstrap_generate_playbook_repo - vendor ``infra.ado`` with ``rsync`` excludes (``.ansible/``, ``.git/``, etc.) so license-only bootstrap does not hang on a full ``ansible.builtin.copy`` of the collection tree.
- capsule_install - Aligned defaults and argument specs with preliminary check variable names.
- ci - Install ``boto3`` and ``botocore`` in Molecule jobs that start fakecloud.
- ci - Keep ``.local`` pip installs and XDG/ansible-lint ``.cache`` out of
  the collection work tree (gitignore, galaxy ``build_ignore``, lint
  excludes). Collection CI helpers under ``scripts/`` stay as Python
  (not Ansible).
- ci - Make ``ansible-lint --offline`` match GitHub CI by mocking
  Automation Hub and community modules that cannot load in the runner,
  wrapping long YAML lines, skipping empty-spec ``args[module]``
  warnings, replacing the IdM AD-trust ``include_role`` handler, and
  fixing ``var-naming`` / ``no-handler`` findings that failed the
  Ansible Lint job.
- ci - Remove committed ``infra-ado-*.tar.gz`` collection build artifacts that caused unit-galaxy ``ade install`` to fail when multiple tarballs were present in the repository.
- ci - Skip tox-ansible ``py3.14`` / ``py3.14-milestone`` sanity entries.
  ansible-test compile treats Python 3.14 ``SyntaxWarning`` as an error for
  ``return`` in a ``finally`` block inside site-packages ``impacket``, which
  is not collection code.
- ci - Stop requiring ``redhat.rhel_idm`` in collection-root ``collections/requirements.yml`` so GitHub Actions Galaxy installs succeed. ``redhat.rhel_idm`` remains in generated playbook-repo requirements for Automation Hub environments.
- grafana_upload_dashboards - Drop ``#!/usr/bin/env python3`` from
  ``adapt-dashboard-for-folder.py``. The task already runs it with
  ``python3``, so a collection shebang is not required.
- infra.ado - Relax ``requires_ansible`` to ``>=2.15.0`` for preflight UI bootstrap hosts.
- infra.ado.bootstrap_controller - Treat ``ansible.hub.ah_collection`` approve ``IndexError`` as non-fatal so Hub publish does not stop bootstrap when force-update is enabled.
- infra.ado.bootstrap_generate_env_vars - Always write ``infra_config_vars.yml`` with shared OpenShift ``host``/``token``/``verify_ssl`` so component playbooks can set ``K8S_AUTH_*``.
- infra.ado.bootstrap_generate_playbook_repo - Prefer ``/workspace/collections`` over vendored ``./collections`` and remove shadowed ``infra.ado`` copies from the generated project.
- infra.ado.bootstrap_generate_playbook_repo - Resolve ``group_vars`` via ``playbook_dir`` and default ``K8S_AUTH_HOST`` from ``api_host`` when ``host`` is unset.
- infra.ado.bootstrap_resolve_component - Added ``acm`` defaults and banner/ACS var aliases; Grafana email/folders stubs.
- infra.ado.bootstrap_resolve_component - Skip dotted registry keys when exporting facts so components with legacy ``infra.ado.*`` entries no longer fail Ansible var naming.
- infra.ado.idm_ad_trust - Detect existing trusts case-insensitively so ``trust-add`` is not retried after a successful establish.
- install_gitlab - Enforce root password with ``gitlab-rails`` after install; ``gitlab.rb`` ``initial_root_password`` only applies on first Omnibus bootstrap, which left Contoller survey passwords (e.g. redhat123) out of sync on re-runs.
- ocp_virtualization - Default instance type ``u1.large`` (8Gi) to avoid ``ErrorUnschedulable`` from ``u1.xlarge`` memory pressure on busy lab workers.
- rhel_sat_reg - Fall back to ``satellite_config_*`` / vault Satellite credentials when ``rhel_sat_reg_*`` is unset, and assert required registration inputs before calling the Satellite API.
- satellite_install - Added missing documented default variables for admin password, reinstall control, and DNS inputs.
- satellite_install - Restart crond instead of chronyd during RHSM subscription tasks.
- satellite_oidc - Accept Keycloak access-token audience ``account`` in
  addition to the client id. Foreman validates the access token, and RHBK
  sets ``aud`` to ``account`` (client id is ``azp``), which caused SSO to
  fail after a successful Keycloak login.
- satellite_oidc - Use Apache ``OIDCResponseType code`` (authorization code)
  instead of ``id_token``. The Keycloak client has implicit flow disabled, so
  the implicit callback POST to ``/users/extlogin/redirect_uri`` returned HTTP 400.

Documentation Changes
---------------------

- Keep republishing ``infra.ado`` as ``1.0.3`` when forcing Hub updates unless a version bump is explicitly requested.
- README - Linked ``infra.ado.idm_ad_trust`` in the collection role index.
- bookstack_openshift / ocp_virtualization - Expand role READMEs for Contoller, images, and scheduling.
- bootstrap_controller - Documented ``ADO | IdM Manage AD Trust`` job template generation for ``idm_ad_trust_install``.
- bootstrap_generate_env_vars - Document migration from legacy
  ``ocp_awspca_*`` vault keys in ``vault_openshift.yml`` /
  ``vault_cert_manager.yml`` to shared ``vault_aws.yml`` plus awspca
  bootstrap playbook remap.
- bootstrap_generate_env_vars - Documented preflight ``additional_environments`` survey choices and IdM AD trust var/vault overlays.
- capsule_install - Added required Role Molecule Testing section to README format verification.
- capsule_install - Aligned ``meta/argument_specs.yml`` with role defaults, including renamed ``capsule_install_*`` options.
- capsule_install - Documented ``capsule_install_selinux_state`` (default ``enforcing``) in the README and argument specs.
- capsule_install - Documented preliminary check validation, grubby/IPv6/SELinux behavior, and reboot handler.
- capsule_install - Removed stale task/template file listings from README role structure and task overview.
- capsule_install - Replaced placeholder argument specs with options aligned to capsule_install defaults.
- capsule_install - Updated README for preliminary check, RHSM subscribe flow, role variables, and role structure.
- capsule_install - Updated README for rhsm_subscribe task flow, renamed defaults, and current role structure.
- capsule_install - Updated README to reflect the current skeleton role and align documented variables with defaults.
- ci - Document fakecloud-backed Molecule testing in
  ``extensions/molecule/FAKECLOUD.md``.
- docs - Document dedicated Hub Postgres as the permanent fix for shared-DB LWLock storms.
- infra.ado.acs_upload_policies - Added template-compliant role README required by galaxy-importer build-import checks.
- infra.ado.ec2_ami_copy - Document optional ``name`` in module examples and
  collection README module index entries.
- infra.ado.grafana_upload_alerts - Added template-compliant role README required by galaxy-importer build-import checks.
- infra.ado.idm_ad_trust - Documented lab defaults, AD DNS forwarder prerequisite, one-way vs two-way trust, and client SSSD checklist in the role README.
- infra.ado.idm_ad_trust - Reformatted role README to match ``docs/templates/role_readme_format_template.md``.
- infra.ado.ocp_aap_hub_harden - Reformatted role README to match the ADO role README template required by CI.
- infra.ado.vpn_access - Added template-compliant role README with usage example and variables table.
- install_gitlab / install_grafana - New standalone RHEL Omnibus GitLab and Grafana roles with Contoller JT/playbook seeds (see ``install_gitlab_grafana`` fragment).
- ocp_awspca - Document bootstrap ``vault_aws.yml`` credential path and
  legacy PCA vault migration for existing environments.
- satellite_install - Updated README task overview and role structure to match current files.

v1.1.0
======

Minor Changes
-------------

- infra.ado.ec2_ami_copy - Added module to copy an AWS AMI between regions with wait, encryption, optional source-tag copy, and tag-based idempotency.

Breaking Changes / Porting Guide
--------------------------------

- Dropped Ansible 2.16 support (EOL). ``meta/runtime.yml`` ``requires_ansible`` is now ``>=2.17.0``, matching CI and the ``amazon.aws`` dependency.

Bugfixes
--------

- ci - Install ``galaxy.yml`` collection dependencies before ``antsibull-changelog release`` so modules that extend external doc fragments (for example ``amazon.aws``) can be parsed during release builds.
- ci - Install the local collection with ``--no-deps`` in Molecule jobs so ``galaxy.yml`` runtime dependencies are not resolved from Galaxy during role scenario runs.
- ci - Skip Ansible 2.16 and ``py3.12-milestone`` tox-ansible sanity/unit matrix entries; ``amazon.aws`` requires Ansible ``>=2.17`` and current ansible-core milestone requires Python ``>=3.13``.
- infra.ado.ec2_ami_copy - Declare ``amazon.aws`` as a collection dependency and fix module documentation metadata so ansible-test validate-modules passes.

Documentation Changes
---------------------

- README - Added collection purpose overview and a complete role index with one-line descriptions and links to each role README.
- README - Documented modules alongside roles; detailed module usage lives under ``docs/modules/``.
- README / docs - Ansible version compatibility updated to ``>=2.17.0``.

New Modules
-----------

- infra.ado.ec2_ami_copy - Copy an AMI between AWS regions.

v1.0.2
======

Minor Changes
-------------

- Bootstrap can materialize OpenShift auth from an uploaded kubeconfig
  (or host+token), then optionally install Admin HTPasswd and NFS CSI
  storage in the preflight pod before AAP install.
- OpenShift Virt network defaults - drop preflight static IP seeding; add optional ip_range guidance for the survey help text while keeping gateway, DNS, and prefix_length as optional survey defaults.
- Wire the ``iscsi_csi`` OpenShift option to ``ocp_iscsi_storage``
  (bundled Synology CSI manifests via kubernetes.core, client-info
  secret from DSM credentials, StorageClass, optional snapshotter)
  with bootstrap prep, playbook, and job template support.
- Wire the ``nfs_csi`` OpenShift option to ``ocp_nfs_storage`` (Helm
  csi-driver-nfs 4.11.0, privileged SCC RoleBindings, StorageClass)
  with playbook and job template support.
- aap_ocp_install - add an ADO wrapper around the vendored infra.aap_utilities 3.5.0 aap_ocp_install role for AAP 2.5 and 2.6 operator/platform deployments on OpenShift.
- bootstrap AAP on OpenShift install - add component_config.aap.minimal_footprint to disable Hub, EDA, and Lightspeed for CPU-constrained clusters (Controller + Gateway only).
- bootstrap AAP on OpenShift install - support component_config.aap.admin_username / admin_password (vault: aap_admin_password). Bootstrap creates the ``{instance}-admin-password`` Secret and sets ``spec.admin_password_secret`` on the AnsibleAutomationPlatform CR.
- bootstrap roles - generate native aap_ocp_install variables and a single AAP-on-OpenShift playbook/job template instead of the incomplete copied AAP 2.4 placeholders.
- bootstrap_controller / preflight - add component_config.aap.install_during_bootstrap. When true, bootstrap writes install vars, runs infra.ado.aap_ocp_install in the preflight pod, and skips playbook/AAP config generation, Controller connectivity/smoke/apply, and the Install AAP job template. Rerun bootstrap once AAP is up to configure the Controller. When false (default), selecting the OpenShift aap app still generates that job template and OpenShift workflow node for later use.
- bootstrap_generate_env_vars - write Satellite manifest uploads as satellite_config_manifest_file (with derived src/path and upload flag) for the Satellite configure playbook.
- bootstrap_generate_env_vars / OpenShift Virt - accept optional preflight static_ip, prefix_length, gateway, and dns_servers values, write them to generated vars (including openshift_virt_network_defaults), and seed the Provision OpenShift Virt VM survey defaults from those values.
- bootstrap_generate_env_vars / bootstrap_controller - configure AAP 2.5+ Automation Gateway authenticators from preflight aap.auth (Keycloak OIDC, LDAP, Keycloak SAML). Writes vault_gateway_auth.yml and applies gateway_authenticators / gateway_authenticator_maps through infra.aap_configuration.dispatch during bootstrap.
- bootstrap_generate_env_vars / satellite_config - emit and default satellite_config_rhn_connected to true; UI/CLI preflight can override with component_config.satellite.rhn_connected.
- bootstrap_generate_playbook_repo - include kubernetes.core and redhat.openshift in generated project collection requirements.

Bugfixes
--------

- CI collections/requirements.yml - drop redhat.openshift. It is not published on public Galaxy (Automation Hub only), which broke ansible-galaxy install in GitHub Actions. Token-auth OpenShift paths use kubernetes.core; username/password login still needs redhat.openshift from Automation Hub at runtime.
- aap_ocp_install, aap_ocp_install_upstream, ocp_iscsi_storage - align role README headings with the collection README format template so README verification passes.
- aap_ocp_install_upstream - do not resolve redhat.openshift.openshift_auth when an OpenShift API token is already provided. Username/password login and token revoke live in separate task files so token-auth installs work with only kubernetes.core (as used by preflight bootstrap).
- bootstrap_controller - fix OpenShift Virt VM survey apply failure where provision_openshift_virt_prefix_length default was emitted as the string "24" instead of integer 24 (quoted placeholder substitution order).
- bootstrap_controller - normalize string and dictionary AAP labels before creating them so generated organization labels do not fail AAP 2.5+ bootstrap runs.
- bootstrap_generate_env_vars / OpenShift Virt playbook - inherit OpenShift skip_tls_verify (and API host/token when blank) for VM provisioning, and fall back to generated OpenShift TLS vars so the job no longer fails when provision_openshift_virt_skip_tls_verify is unset.
- bootstrap_generate_playbook_repo - configure generated AAP projects to sync on launch and wait for project creation so job runs pick up current collection requirements from the generated repository.
- bootstrap_generate_playbook_repo - generate infra.ado collection requirements with only the collection name and version so AAP resolves the source through its configured content repositories.
- bootstrap_resolve_component - normalize app_domain from the generated apps_domain value (or derive apps.<domain> for legacy vars) before rendering component defaults, and register openshift_virt so VM provisioning no longer fails during common variable resolution.
- ci - remove unsupported ``user`` platform key from ``integration_rhel_patching`` and ``integration_rhel_repos_default`` Molecule configs so podman driver schema validation passes.
- ocp_iscsi_storage - wrap multi-document CSI manifests as Kubernetes List resources and clear executable bits so ansible-test yamllint and shebang sanity checks pass.

v1.0.1
======

Minor Changes
-------------

- Add OpenShift Virtualization VM launch survey options for image preference, instance type, custom CPU and memory, disk size, static networking, password setup, and optional root SSH.
- Add Satellite install sizing, storage mount, deployment version, RHN organization, location, admin password, and activation key defaults to the bootstrap env var generator so UI and CLI preflight runs can populate the Satellite install role.
- Add default Satellite install tuning tiers and storage mount definitions to the Satellite install role.
- Add optional OpenShift Virtualization VM provisioning to bootstrap generation, including component vars, generated playbook repo content, and an AAP job template for CLI and UI preflight runs.
- Limit OpenShift Virtualization preflight-derived values to the OpenShift API endpoint, API token, TLS verification setting, and SSH public key so VM sizing and guest customization are controlled from the AAP launch survey.
- bootstrap_controller - Publishes the generated infra.ado collection to AAP Hub on AAP 2.5+ runs when the Hub publish option is enabled.
- bootstrap_controller - Stops after the AAP Hub publish step when the collection-only update flag is enabled.
- bootstrap_generate_env_vars - Added a collection-only Hub update flag so callers can update infra.ado in AAP Hub without generating component bootstrap content.
- bootstrap_generate_env_vars - Added a generated force-update toggle for publishing the bundled infra.ado collection to validated content in AAP Hub.
- collection - Fill out galaxy metadata with ADO project links, tags, and runtime collection dependencies.
- collection - Standardize the collection and role Ansible requirement metadata on ansible-core 2.16.
- roles - Flatten task entrypoints that only imported a single task file.

Bugfixes
--------

- Apply generated AAP inventory sources directly with ansible.controller so Satellite dynamic inventory sources are created when enabled from either the UI preflight JSON or CLI variables.
- Generated env var YAML now suppresses YAML anchors and preserves machine credential SSH private keys with a trailing newline instead of extra spaces.
- Keep Automation Hub and optional runtime collections out of galaxy.yml hard dependencies so installing the built infra.ado artifact does not fail when public Galaxy cannot resolve Red Hat or local-only collections.
- Normalize generated AAP survey choices so list values remain separate options instead of collapsing into a single dropdown entry.
- Remove remaining install-time galaxy.yml dependency resolution so pod and offline installs of infra.ado use container-provided collection tarballs.
- Satellite RHN organization IDs and activation keys are written as vault-backed values, with activation keys preserved when supplied by the UI.
- Satellite bootstrap playbooks now load generated env vars from the project root when running under AAP and enable become where host changes require it.
- Satellite install VG name is now generated from preflight/CLI input and raw installer-only fields are no longer duplicated under generic component config.
- Satellite install role defaults and task references now consistently use `satellite_install_rhn_*`, `satellite_install_size*`, `satellite_install_min_*`, and other non-duplicated install variable names.
- Satellite storage install variables now use the names consumed by the storage tasks, including `satellite_install_vg_name`, `satellite_install_req_dirs`, and `satellite_install_data_*`.
- Stop silently removing checked Satellite dynamic inventory sources during AAP credential-type preflight unless the compatibility skip flag is explicitly enabled.
- bootstrap_controller - Corrects AAP controller auth preflight messages to reference the generated aap_vault.yml file.
- bootstrap_controller - Loads generated AAP config variables and enables the AAP apply path for collection-only Hub update runs so the Hub publish step is not skipped.
- bootstrap_controller - Passes the generated AAP Hub repository target when publishing infra.ado so collection updates land in validated content instead of the published repository.
- bootstrap_controller - Stops waiting indefinitely on AAP Hub collection import processing after the upload is submitted so UI runs can return the final recap.
- bootstrap_generate_env_vars - Handles empty component and platform lists when running in AAP Hub collection-only update mode.
- bootstrap_generate_env_vars - Treats an empty Satellite deployment version as missing and writes the default 6.19 value.
- bootstrap_generate_env_vars - point the generated AAP execution environment at the supported AAP 2.6 RHEL 9 execution environment image instead of the generic AWX EE image so Satellite inventory syncs can load redhat.satellite.foreman.
- bootstrap_generate_env_vars - render the Satellite TLS validation setting into dynamic inventory source vars so AAP Satellite inventory syncs honor the UI and CLI skip TLS setting.
- bootstrap_generate_playbook_repo - Generates project collection requirements with an infra.ado version pin and AAP Hub source URL so AAP project syncs install the collection version containing newly generated roles such as ocp_virtualization.
- satellite_config - Defaults the Satellite deployment version to 6.19 for repository label generation.
- satellite_install - Defaults the Satellite deployment version to 6.19 so installs do not fail preliminary validation when generated vars omit the version.

v1.0.0
======

Minor Changes
-------------

- Add RHEL patching survey prompts for reboot behavior, package selection, package state, exclusions, disabled repositories, cache refresh, kernel cleanup, and skip-broken handling.
- Add Satellite service account inputs to generated environment vars so Satellite configuration can connect using UI or CLI-provided credentials.
- Add optional Satellite 6 dynamic inventory source generation for AAP, including a Satellite credential and inventory source settings for UI and CLI preflight runs.
- Added ACM bootstrap playbook and job template coverage so selected ACM components produce AAP content.
- Added OpenShift htpasswd, console banner, and cert-manager configuration variables for generated UI and CLI preflight runs.
- Added an OpenShift bootstrap workflow that includes selected admin htpasswd, cert-manager, console banner, RHBK, Grafana, GitLab, Pega, Kafka, AAP, ECK, GitOps, 389ds, OADP, Quay, ACS, and ACM job templates when those templates are generated.
- Bootstrap generation now removes playbook, environment variable, vault, and AAP job template artifacts for components that are no longer selected.
- Check AAP controller API connectivity before applying bootstrap controller objects and run a configurable demo job template smoke test.
- Correct the Satellite registration job template survey definition to use survey_spec and the standard bootstrap controller variables.
- Normalize RHEL patching list inputs so AAP survey text answers can be used as package, exclude, and disabled repository lists.
- Sync generated bootstrap playbook repositories with the remote branch before pushing so repeated UI or CLI generation runs can rebase on origin first.
- aap_build_ee - Added optional ``aap_build_ee_ansible_core`` and ``aap_build_ee_ansible_runner`` variables for minimal base image builds.
- aap_build_ee - Normalized ``aap_build_ee_collections`` input to support dict, list, and flat object formats when rendering ``requirements.yml``.
- aap_build_ee - Updated ``aap_build_ee_collections`` to accept a mapping of collection name to version constraint for generated ``requirements.yml``.
- ado-preflight-ui - Add Satellite field help, consistent skip-TLS wording, IDM configuration controls, immediate SSH key paste support, and an end-of-run ADO bootstrap recap.
- bootstrap_controller - add an AAP job template for RHEL STIG hardening with surveys for environment, compliance profile, and STIG profile.
- bootstrap_controller - attach the organization label to generated AAP job templates and workflow templates so each bootstrap run has an org-based top-level filter label in addition to component labels.
- bootstrap_controller - prefix generated job and workflow template names with the configured AAP organization.
- bootstrap_controller - verify the organization label exists in AAP after label creation so missing domain/filter labels fail visibly during bootstrap.
- bootstrap_generate_env_vars - Added generated AAP Machine credential support for RHEL, Satellite, and patching workflows, including ``vault_machine_cred.yml`` for SSH key material.
- bootstrap_generate_env_vars - Prefer component app selections over stale selected_component_apps values when importing older preflight JSON files.
- bootstrap_generate_env_vars - Preserve UI and CLI IDM configuration fields for DNS, replica, certificate, custom certificate, and auto-forwarder settings while removing the obsolete IDM storage value.
- bootstrap_generate_env_vars - add AAP additional credential inputs, org-based AAP object naming, and hub collection toggle vars for UI and CLI preflight flows.
- bootstrap_generate_env_vars - allow UI and CLI preflight JSON RHEL STIG options to generate the STIG component artifacts and profile vars.
- bootstrap_generate_env_vars - map OpenShift LDAP, OAuth/RHBK, route discovery, and pull secret checkboxes to distinct component app keys so UI and CLI payloads can select them independently.
- bootstrap_generate_playbook_repo - add a RHEL STIG hardening bootstrap playbook and optional generated repository STIG requirements for ``redhat.rhel_system_roles`` without making it a hard dependency of ``infra.ado`` installation.
- ci - Add changelog preview for dev pre-releases, including release notes and a downloadable ``CHANGELOG-preview.rst`` asset built from accumulated fragments.
- ci - Added ADO collection roles to ``mock_roles`` and excluded generated bootstrap seed payloads from source lint checks.
- ci - Added automatic collection build and GitHub Release asset attachment for dev tag pre-releases and published releases. Ansible Galaxy publish is now manual via the Release infra.ado workflow_dispatch job.
- ci - Generate ``CHANGELOG.rst`` from accumulated changelog fragments automatically when a GitHub Release is published, commit the result to ``main``, and include the changelog in the release collection tarball.
- docs - Add a role documentation index to the collection README with links to each role README.
- ocp_console_banner - accept add/update/delete state aliases while keeping present/new/absent compatibility.
- rhel_ext_system_roles - add support for invoking the upstream STIG RHEL system role through the existing wrapper.
- rhel_repos - Added Podman Molecule integration scenario on UBI 8 and UBI 9.
- satellite_config - Added a condition so third-party products and repositories are created on Satellite only when satellite_products is defined and non-empty.
- satellite_config - Added a condition to create third-party products and repositories on Satellite only when satellite_products is defined and non-empty.
- satellite_config - Added condition to create 3rd party products and repositories on Satellite only when satellite_products is defined and non-empty.

Breaking Changes / Porting Guide
--------------------------------

- rhel_repos - Renamed role from ``platform_repos``; use ``infra.ado.rhel_repos`` and ``rhel_repos_*`` variables instead of ``platform_repos_*``.

Removed Features (previously deprecated)
----------------------------------------

- platform_ec2 - Removed role.

Bugfixes
--------

- Add generated RHEL compliance and Satellite install/config/content-view playbooks and job templates, plus RHEL and Satellite workflow templates that target the matching generated component inventories.
- Attach the plain organization label to generated job templates and workflows so AAP domain/filter views can show the organization grouping.
- Create an organization label/domain such as ADO and keep generated job-template and workflow labels organization-prefixed.
- Generate both a focused patching workflow and a full RHEL workflow with simplified workflow nodes so AAP creates workflow templates reliably.
- Generate component-specific AAP inventories so the default inventory contains only localhost, RHEL managed hosts use the RHEL inventory, IDM hosts use the IDM inventory, and Satellite server jobs use the Satellite server inventory.
- Generate workflow template labels as top-level label lists instead of related label strings so infra.aap_configuration can create workflow templates without failing on missing label object names.
- Ignore stale component app selections from inactive groups so an OpenShift run with old RHEL/Satellite JSON state does not enable Satellite dynamic inventory or require Satellite service account fields.
- Keep optional OpenShift configuration jobs, such as Console Banner and Admin HTPasswd, as independent workflow start branches so they are added to AAP workflows even when other optional OpenShift jobs are not selected.
- Load OpenShift htpasswd and console banner jobs from vars_openshift and vault_openshift so selected OpenShift runs do not depend on ungenerated vars_htpasswd or vars_common files.
- Load generated AAP and component vault files before rendering controller config files so Satellite dynamic inventory credentials can reference generated vault variables.
- Map generated workflow config files to the controller_workflows dispatcher variable so AAP workflow templates are applied, not only written to Git.
- Normalize additional AAP credential names and Satellite dynamic inventory object names to the organization-prefixed naming pattern.
- Normalize generated AAP project names to the organization-prefixed naming pattern so UI and CLI inputs such as test-project become RH-test-project when the organization is RH.
- Normalize generated primary AAP Vault and Machine credential names to the organization-prefixed naming pattern so UI and CLI inputs such as test-vault and test-machine become RH-test-vault and RH-test-machine when the organization is RH.
- Normalize generated primary AAP inventory names to the organization-prefixed naming pattern so inputs such as test-inventory become RH-test-inventory when the organization is RH.
- Preflight the optional Satellite 6 dynamic inventory credential type before applying AAP credentials, and skip only the Satellite inventory source when that credential type is unavailable.
- Preserve vault variable references in generated controller credential config files instead of resolving secrets during config generation.
- Prune generated workflow nodes that reference unselected job templates so partial OpenShift app selections do not create invalid AAP workflows.
- Refresh generated AAP config and vault files on preflight JSON runs so UI reruns do not keep stale controller object definitions.
- Reload generated controller config files before applying AAP objects so split inventories, hosts, inventory sources, labels, job templates, and workflow templates are created from the current UI or CLI run.
- Render additional AAP credentials with credential-type-specific inputs, so Vault credentials use vault_password instead of machine credential fields.
- Render generated Console Banner survey choices as AAP-compatible newline-separated options so the default update action is accepted and OpenShift workflow creation is not blocked during AAP dispatch.
- Restore generated vault file encryption for preflight/UI runs and allow noninteractive CLI runs to provide a vault password file.
- Skip the post-AAP-config Git push when only AAP configs are generated and no playbook repository was generated.
- Stop adding the Satellite TLS verification flag to Satellite credential inputs because AAP credential schemas may not accept it as a credential field.
- Treat Satellite dynamic inventory as enabled when older preflight JSON selects Satellite but omits the dynamic inventory setting.
- aap_build_ee - Fixed ``ansible_core`` and ``ansible_runner`` rendering to use ansible-builder 3.x ``package_pip`` object schema.
- bootstrap_controller - Continue bootstrap runs when the optional smoke-test job template is missing after AAP connectivity succeeds.
- bootstrap_controller - Report safe AAP connectivity failure details instead of stopping on a fully censored no_log result, and persist the UI or CLI TLS validation setting into generated AAP vars.
- bootstrap_controller - Use the AAP 2.5 and 2.6 controller gateway API path for connectivity and smoke-test checks while keeping the AAP 2.4 controller API path.
- bootstrap_controller - include the UI or CLI supplied environment name in generated AAP job and workflow template survey choices and use it as the default environment.
- bootstrap_controller - include the console banner job template in generated OpenShift workflows and expose add/update/delete survey choices for banner management.
- bootstrap_controller - only generate optional OpenShift and RHBK AAP job templates when their matching options are selected, preventing unchecked resources from being created in AAP.
- bootstrap_generate_env_vars - gate OpenShift HTPasswd admin and console banner values behind `component_options.openshift` entries so UI and CLI preflight runs only generate those optional settings when selected.
- bootstrap_generate_env_vars - infer OpenShift console banner and HTPasswd option apps from submitted option values as a fallback for older UI payloads that omitted `component_options`.
- bootstrap_generate_env_vars - prefer modern `components` and `component_apps` preflight fields over the legacy `selected_component_apps` list so OpenShift option changes are not collapsed to a selected child app such as RHBK.
- bootstrap_generate_playbook_repo - Fixed generated bootstrap seed playbook YAML indentation and malformed ``vars_files`` entries so generated playbooks pass syntax and lint checks.
- bootstrap_generate_playbook_repo - Fixed generated bootstrap seed playbooks to reference real role names for ``include_role`` tasks.
- bootstrap_generate_playbook_repo - generate an OpenShift-scoped console banner playbook when the OpenShift console banner option is selected so UI and CLI runs create the workflow job target under `playbooks/openshift`.
- bootstrap_generate_playbook_repo - only copy optional OpenShift LDAP, OAuth/RHBK, route discovery, pull secret, and RHBK realm/client/IDP/ federation playbooks when their matching options are selected.
- ci - Ensure changelog fragments are only consumed and deleted when an official GitHub Release is published. Dev tag pushes and pre-releases now use preview-only changelog generation with a post-run verification that repository fragments are unchanged.
- ci - Fix changelog PR creation after releases by removing the generated-only guard, staging fragment deletions correctly, and improving PR branch handling.
- ci - Fix changelog generation to use ``antsibull-changelog release --version``, render ``CHANGELOG.rst`` from fragments, and set GitHub Release notes from the compiled changelog instead of auto-generated commit summaries.
- ci - Install mikefarah/yq in collection build jobs instead of the Ubuntu ``yq`` package, which does not support ``yq -i`` for updating ``galaxy.yml`` version on tag builds.
- ci - Move Ansible Galaxy publish to a separate manual-only workflow so GitHub Release events no longer trigger automatic Galaxy publication from ``main``.
- ci - Remove the non-compliant shebang from ``scripts/validate_release_version.py`` so ansible-test sanity shebang checks pass.
- ci - Stop overwriting ``galaxy.yml`` namespace during tag builds so release tarballs are built as ``infra.ado`` instead of ``ado.ado``.
- ci - Stop syncing ``.github/actions`` from ``main`` during release jobs so tag builds use the pipeline from the checked-out branch or tag ref.
- ci - Sync ``.github/actions`` from ``main`` during release jobs so tags use the current changelog tooling, validate release versions for antsibull-changelog compatibility, and fail early on invalid tags such as ``249.0.0.1-rc1``.
- ci - Use fully qualified ``refs/heads/`` refspec when pushing changelog release branches from detached HEAD checkouts in Actions.
- ocp_operatorgroups - Fixed task imports to reference existing ``create_operatorgroup.yml`` and ``delete_operatorgroup.yml`` task files.

Documentation Changes
---------------------

- Align bootstrap playbook examples with role README basic usage examples.
- CODE_OF_CONDUCT - Added repository Code of Conduct with Ansible Community CoC adoption and ADO addendum.
- bootstrap_resolve_component - Replaced a smart quote in the role README so Ansible sanity ``no-smart-quotes`` passes.
- ci - Expanded ``.github/README.md`` into a full developer and maintainer guide covering all GitHub Actions workflows, PR requirements, Molecule testing, local validation, collection builds, dev pre-releases, official releases, and troubleshooting.
- kafka_install - Restored the README environment authentication section required by the role's Molecule verify scenario.
- roles - Normalized role README files to match the repository role README format template and replaced generated placeholder text with role-specific summaries, variables, usage, and test notes.
