# Role: infra.automation_development_office.ocp_devspaces

Ocp Devspaces automation role. Primary tasks include: Delete Devspaces instance using Operator; Resolve DevSpaces namespaces; Wait for Dev Spaces CSV to reach 'Succeeded.

## Role Author

Automation Development Office

## ✅ Role Requirements

- Ansible Core
- Required collections listed in `collections/requirements.yml`
- Inventory or extra variables appropriate for the target platform

## 📦 Role Variables

| Variable | Description |
|----------|-------------|
| `ocp_devspaces_state` | Desired state used by role tasks when supported. |
| `ocp_devspaces_disable_default_samples` | When true, replace stock getting-started samples with ``custom_samples`` (or empty). |
| `ocp_devspaces_custom_samples` | List of sample objects (``displayName``, ``description``, ``tags``, ``url``, optional ``icon``). Blank ``url`` is filled with this Che host's built-in Empty Workspace UDI ``empty.yaml`` so the card still shows. ConfigMap is written to the CheCluster/dashboard namespace. |
| `ocp_devspaces_custom_sample_icon_source` | ``bundled`` (role ``files/ado-sample-icon.png``) or ``upload`` (icon already in sample). |
| `ocp_devspaces_default_devfile_url` | Optional single sample URL when custom_samples is empty. |
| `ocp_devspaces_default_workspace_image` | Optional default workspace container image. |
| `ocp_devspaces_status_exporter_enabled` | When true (default), deploy DevWorkspace phase/reason metrics exporter for Grafana (``dw_*`` labels) and scrape VS Code / CheCode extensions (``devworkspace_vscode_extension``). Needs ``pods`` + ``pods/exec``. The exporter probes the CheCode editor container first (not only ``tooling-container``). |
| `ocp_devspaces_status_exporter_namespace` | Namespace for the exporter (default: operator namespace). |

## 🚀 Role Usage

```yaml
- name: Run ocp_devspaces
  hosts: localhost
  gather_facts: false
  roles:
    - role: infra.automation_development_office.ocp_devspaces
```

Blank custom sample URLs are filled in ``tasks/fill-custom-sample-urls.yml``.
That task does not call Jinja ``namespace()``, so a string variable named
``namespace`` does not break the sample list.

Exporter-only (does not install Dev Spaces):

```bash
ansible-playbook playbooks/devspaces/ado-devspaces-status-exporter.yml
```

Or tag the existing install playbook: ``--tags status_exporter``.

## 🧪 Role Molecule Testing

Run Molecule scenarios from the role directory when a scenario is available.

This role runs tasks such as:

- Delete Devspaces instance using Operator
- Resolve DevSpaces namespaces
- Wait for Dev Spaces CSV to reach 'Succeeded
- Ensure DevSpaces app namespace exists

```bash
cd roles/ocp_devspaces
molecule test
```

## 📁 Role Structure

```text
roles/ocp_devspaces/
  README.md
  defaults/
  handlers/
  meta/
  tasks/
  tests/
  vars/
```

## GitOps generation preview

Set `ocp_devspaces_delivery_mode: generate` and `ocp_devspaces_gitops_repo_url` to
render a Namespace and CheCluster without cluster access. Direct installation
remains the default. Both paths use `tasks/build-checluster.yml`. Optional
`ocp_devspaces_gitops_revision`, `ocp_devspaces_gitops_path`,
`ocp_devspaces_gitops_namespace`, `ocp_devspaces_gitops_project`,
`ocp_devspaces_gitops_destination`, and `ocp_devspaces_gitops_output_dir` control
repository/destination settings. Default resource paths include `env` (or
`default` when absent); Application names are `devspaces-<env>`.

This first export covers the Namespace/CheCluster only. Dashboard sample
ConfigMaps, status exporter, operator subscription, and additional route handling
are excluded. Hostname, dashboard-image override, and workspace-image settings
use the shared CheCluster builder. The operator/CRDs must exist before syncing.
Do not run direct ADO application reconciliation against an Argo-managed CR.
Switching delivery modes does not automatically transfer or remove ownership.

Custom hostnames use the CheCluster v2 `spec.networking.hostname` field. Readiness reads the same resource name and namespace as the desired manifest. A missing resource after a successful apply requires investigation of deletion/reconciliation on the target cluster.
