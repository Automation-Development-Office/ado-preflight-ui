# infra.aap_configuration.controller_projects

## Description

An Ansible Role to create/update/remove Projects on Ansible Controller.

## Requirements

ansible-galaxy collection install -r tests/collections/requirements.yml to be installed

## Variables

|Variable Name|Default Value|Required|Type|Description|Example|
|:---|:---:|:---:|:---|:---|:---|
|`controller_state`|"present"|no|str|The state all objects will take unless overridden by object default|'absent'|
|`aap_hostname`|""|yes|str|URL to the Ansible Controller Server.|127.0.0.1|
|`aap_validate_certs`|`true`|no|str|Whether or not to validate the Ansible Controller Server's SSL certificate.||
|`aap_username`|""|no|str|Admin User on the Ansible Controller Server. Either username / password or oauthtoken need to be specified.||
|`aap_password`|""|no|str|Controller Admin User's password on the Ansible Controller Server. This should be stored in an Ansible Vault at vars/controller-secrets.yml or elsewhere and called from a parent playbook. Either username / password or oauthtoken need to be specified.||
|`controller_oauthtoken`|""|no|str|Controller Admin User's token on the Ansible Controller Server. This should be stored in an Ansible Vault at or elsewhere and called from a parent playbook. Either username / password or oauthtoken need to be specified.||
|`controller_request_timeout`|`10`|no|int|Specify the timeout in seconds Ansible should use in requests to the Ansible Automation Platform host.||
|`aap_configuration_collect_logs`|`false`|no|bool|Specify whether to collect async results and continue for all failed async tasks instead of failing on the first error. Collected results are available in the `aap_configuration_role_errors` variable.||
|`controller_projects`|`see below`|yes|str|Data structure describing your project or projects Described below. Alias: projects||

### Enforcing defaults

The following Variables complement each other.
If Both variables are not set, enforcing default values is not done.
Enabling these variables enforce default values on options that are optional in the controller API.
This should be enabled to enforce configuration and prevent configuration drift. It is recommended to be enabled, however it is not enforced by default.

Enabling this will enforce configuration without specifying every option in the configuration files.

'controller_configuration_projects_enforce_defaults' defaults to the value of 'aap_configuration_enforce_defaults' if it is not explicitly called. This allows for enforced defaults to be toggled for the entire suite of controller configuration roles with a single variable, or for the user to selectively use it.

|Variable Name|Default Value|Required|Description|
|:---:|:---:|:---:|:---:|
|`controller_configuration_projects_enforce_defaults`|`false`|no|Whether or not to enforce default option values on only the applications role|
|`aap_configuration_enforce_defaults`|`false`|no|This variable enables enforced default values as well, but is shared across multiple roles, see above.|

### Secure Logging Variables

The following Variables complement each other.
If Both variables are not set, secure logging defaults to false.
The role defaults to false as normally the add projects task does not include sensitive information.
controller_configuration_projects_secure_logging defaults to the value of aap_configuration_secure_logging if it is not explicitly called. This allows for secure logging to be toggled for the entire suite of configuration roles with a single variable, or for the user to selectively use it.

|Variable Name|Default Value|Required|Type|Description|
|:---:|:---:|:---:|:---:|:---|
|`controller_configuration_projects_secure_logging`|`false`|no|str|Whether or not to include the sensitive Project role tasks in the log. Set this value to `true` if you will be providing your sensitive values from elsewhere.|
|`aap_configuration_secure_logging`|`false`|no|str|This variable enables secure logging as well, but is shared across multiple roles, see above.|

### Asynchronous Retry Variables

The following Variables set asynchronous retries for the role.
If neither of the retries or delay or retries are set, they will default to their respective defaults.
This allows for all items to be created, then checked that the task finishes successfully.
This also speeds up the overall role.

|Variable Name|Default Value|Required|Type|Description|
|:---:|:---:|:---:|:---:|:---|
|`aap_configuration_async_retries`|50|no|str|This variable sets the number of retries to attempt for the role globally.|
|`controller_configuration_projects_async_retries`|`{{ aap_configuration_async_retries }}`|no|str|This variable sets the number of retries to attempt for the role.|
|`aap_configuration_async_delay`|1|no|str|This sets the delay between retries for the role globally.|
|`controller_configuration_projects_async_delay`|`aap_configuration_async_delay`|no|str|This sets the delay between retries for the role.|
|`aap_configuration_loop_delay`|0|no|int|This sets the pause between each item in the loop for the roles globally. To help when API is getting overloaded.|
|`controller_configuration_projects_loop_delay`|`aap_configuration_loop_delay`|no|int|This sets the pause between each item in the loop for the role. To help when API is getting overloaded.|
|`aap_configuration_async_dir`|`null`|no|bool|Sets the directory to write the results file for async tasks. The default value is set to `null` which uses the Ansible Default of `/root/.ansible_async/`.|

## Data Structure

### Project Variables

|Variable Name|Default Value|Required|Type|Description|
|:---:|:---:|:---:|:---:|:---:|
|`name`|""|yes|str|Name of Project|
|`new_name`|""|no|str|Setting this option will change the existing name (looked up via the name field).|
|`copy_from`|""|no|str|Name or id to copy the project from. This will copy an existing project and change any parameters supplied.|
|`description`|`false`|no|str|Description of the Project.|
|`organization`|`false`|yes|str|Name of organization for project.|
|`scm_type`|""|no|str|Type of SCM resource.|
|`scm_url`|""|no|str|URL of SCM resource.|
|`default_environment`|""|no|str|Default Execution Environment to use for jobs relating to the project.|
|`local_path`|""|no|str|The server playbook directory for manual projects.|
|`scm_branch`|""|no|str|The branch to use for the SCM resource.|
|`scm_refspec`|""|no|str|The refspec to use for the SCM resource.|
|`credential`|""|no|str|Name of the credential to use with this SCM resource.|
|`signature_validation_credential`|""|no|str|Name of the credential to use for signature validation. If signature validation credential is provided, signature validation will be enabled.|
|`scm_clean`|""|no|bool|Remove local modifications before updating.|
|`scm_delete_on_update`|""|no|bool|Remove the repository completely before updating.|
|`scm_track_submodules`|""|no|bool|Track submodules latest commit on specified branch.|
|`scm_update_on_launch`|""|no|bool|Before an update to the local repository before launching a job with this project.|
|`scm_update_cache_timeout`|""|no|str|Cache Timeout to cache prior project syncs for a certain number of seconds. Only valid if scm_update_on_launch is to true, otherwise ignored.|
|`allow_override`|""|no|str|Allow changing the SCM branch or revision in a job template that uses this project.|
|`timeout`|""|no|int|The amount of time (in seconds) to run before the SCM Update is canceled. A value of 0 means no timeout.|
|`custom_virtualenv`|""|no|str|Local absolute file path containing a custom Python virtualenv to use.|
|`notification_templates_started`|""|no|list|The notifications on started to use for this organization in a list.|
|`notification_templates_success`|""|no|list|The notifications on success to use for this organization in a list.|
|`notification_templates_error`|""|no|list|The notifications on error to use for this organization in a list.|
|`state`|`present`|no|str|Desired state of the resource.|
|`register`|""|no|str|Variable to set based on the result of the object creation/modification|
|`wait`|""|no|bool|Provides option to wait for completed project sync before returning.|
|`update_project`|`false`|no|bool|Force project to update after changes.Used in conjunction with wait, interval, and timeout.|
|`interval`|`controller_configuration_projects_async_delay`|no|float|The interval to request an update from controller. Requires wait.|
|`roles`|""|no|obj|Controller roles to apply to the project. See roles section below for how to apply.|

#### Applying roles to users or teams

You can apply roles to users or teams using the `roles` field. This is applied as a dictionary as follows:

```yaml
- name: my_project
  roles:
    use:
      teams:
        - myteam1
        - myteam2
    admin:
      users:
        - sysadmin1
    update:
      teams:
        - myteam1
        - myteam2
```

This functionality can be disabled by setting `aap_configuration_apply_object_roles` as `false`.

### Standard Project Data Structure

#### Json Example

```json
{
    "controller_projects": [
      {
        "name": "controller Config",
        "organization": "Default",
        "scm_branch": "master",
        "scm_clean": "no",
        "scm_delete_on_update": "no",
        "scm_type": "git",
        "scm_update_on_launch": "no",
        "scm_url": "https://github.com/ansible/tower-example.git",
        "notification_templates_error": [
          "Slack_for_testing"
        ]
      }
    ]
  }

```

#### Yaml Example

```yaml
---
controller_projects:
- name: controller Config
  organization: Default
  scm_branch: master
  scm_clean: 'no'
  scm_delete_on_update: 'no'
  scm_type: git
  scm_update_on_launch: 'no'
  scm_url: https://github.com/ansible/tower-example.git
  notification_templates_error:
  - Slack_for_testing

```

## Playbook Examples

### Standard Role Usage

```yaml
---
- name: Playbook to configure ansible controller post installation
  hosts: localhost
  connection: local
  # Define following vars here, or in aap_configs/auth.yml
  # aap_hostname: aap.example.com
  # aap_username: admin
  # aap_password: changeme
  pre_tasks:
    - name: Include vars from platform_configs directory
      ansible.builtin.include_vars:
        dir: ./yaml
        ignore_files: [controller_config.yml.template]
        extensions: ["yml"]
  roles:
    - {role: infra.aap_configuration.controller_projects, when: controller_projects is defined}
```

## License

[GPLv3+](https://github.com/redhat-cop/infra.aap_configuration/blob/devel/LICENSE)

## Author

[Sean Sullivan](https://github.com/sean-m-sullivan)
