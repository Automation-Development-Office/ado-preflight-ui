#!/usr/bin/env bash
# Copyright (c) Ansible Project
# GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or https://www.gnu.org/licenses/gpl-3.0.txt)
# SPDX-License-Identifier: GPL-3.0-or-later

set -eux

# This doesn't work well with the default container for some (older?) ansible-core versions:
# source virtualenv.sh

# Requirements have to be installed prior to running ansible-playbook
# because plugins and requirements are loaded before the task runs

ANSIBLE_ROLES_PATH=../ ansible-playbook setup.yml "$@"

ANSIBLE_ROLES_PATH=../ ansible-playbook runme.yml "$@"
