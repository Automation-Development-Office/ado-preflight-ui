# Role: infra.ado.rhel_ext_system_roles

Rhel Ext System Roles automation role. Primary tasks include: Gather minimal facts for RHEL System Roles (expanded subset); Normalize wrapper inputs; Normalize SELinux inputs.

## Role Author

Automation Development Office

## ✅ Role Requirements

- Ansible Core
- Required collections listed in `collections/requirements.yml`
- Inventory or extra variables appropriate for the target platform

## 📦 Role Variables

| Variable | Description |
|----------|-------------|
| `rhel_ext_system_roles_roles_map` | Role input variable used to configure automation behavior. |

## 🚀 Role Usage

```yaml
- name: Run rhel_ext_system_roles
  hosts: localhost
  gather_facts: false
  roles:
    - role: infra.ado.rhel_ext_system_roles
```

## 🧪 Role Molecule Testing

Run Molecule scenarios from the role directory when a scenario is available.

This role runs tasks such as:

- Gather minimal facts for RHEL System Roles (expanded subset)
- Normalize wrapper inputs
- Normalize SELinux inputs
- Map selinux_state to role-accepted values

```bash
cd roles/rhel_ext_system_roles
molecule test
```

## 📁 Role Structure

```text
roles/rhel_ext_system_roles/
  README.md
  defaults/
  handlers/
  meta/
  tasks/
  tests/
  vars/
```
